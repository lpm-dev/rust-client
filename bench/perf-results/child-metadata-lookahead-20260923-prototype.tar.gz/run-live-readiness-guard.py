from pathlib import Path
import os, json, hashlib, subprocess, sys
repo=Path('/Users/tolga/.codex/worktrees/install-overhead/rust-client')
root=Path('/tmp/lpm-metadata-lookahead')
baseline=Path('/tmp/lpm-next-install-costs/lpm-timeline')
candidate=root/'lpm-lookahead-guard'
node='/opt/homebrew/bin/node'
common=[node,str(repo/'bench/scripts/run-install-readiness.mjs'),
 '--fixtures',f'vite-react,native-sharp,nest,t3={repo}/bench/audit-fixtures/t3-install',
 '--managers','lpm,bun','--modes','cold',
 '--lpm-routes','direct','--lpm-firewall-modes','off',
 '--lpm-binary',f'baseline={baseline}','--lpm-binary',f'candidate={candidate}',
 '--timeout-ms','120000']
plan={'baseline':str(baseline),'candidate':str(candidate),'sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [baseline,candidate]},'method':'Two unscored warmup rounds with successful-install gate; 12 scored rounds; built-in balanced execution order; all four fixtures; live registry inputs may differ; no builds/tests during scoring. Readiness enables its standard detailed timers for both LPM binaries.'}
(root/'live-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for stage,samples in [('warm',2),('scored',12)]:
 output=root/f'live-first-install-{stage}';assert not output.exists()
 args=common+['--samples',str(samples),'--output',str(output)]
 if stage=='scored':args+=['--lpm-compare','baseline:candidate']
 with (root/f'live-first-install-{stage}.log').open('w') as log:
  result=subprocess.run(args,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 (root/f'live-first-install-{stage}-exit.json').write_text(json.dumps({'exit_code':result.returncode,'command':args},indent=2))
 print(stage,'exit',result.returncode,flush=True)
 if result.returncode:
  print((root/f'live-first-install-{stage}.log').read_text()[-3000:],flush=True)
  sys.exit(result.returncode)
