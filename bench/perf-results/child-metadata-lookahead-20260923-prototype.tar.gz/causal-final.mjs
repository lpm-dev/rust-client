import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import http2 from 'node:http2';
import net from 'node:net';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {benchmarkTls} from '/Users/tolga/.codex/worktrees/install-overhead/rust-client/bench/scripts/cold-object-finalization-replay/tls.mjs';
import {requestKey,validateAuthority} from '/Users/tolga/.codex/worktrees/install-overhead/rust-client/bench/scripts/cold-object-finalization-replay/replay-proxy.mjs';
const root=process.argv[2];assert(root&&!fs.existsSync(root));fs.mkdirSync(root,{recursive:true});
const tls=benchmarkTls(root), names=['lookahead-a','lookahead-b','lookahead-c'];
const binaries={baseline:'/tmp/lpm-next-install-costs/lpm-timeline',candidate:'/tmp/lpm-metadata-lookahead/lpm-lookahead'};
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function tarball(name){
 const manifest=Buffer.from(JSON.stringify({name,version:'1.0.0',...(name===names[1]?{dependencies:{[names[2]]:'1.0.0'}}:{})}));
 const header=Buffer.alloc(512);header.write('package/package.json');
 for(const [at,size,value] of [[100,8,0o644],[108,8,0],[116,8,0],[124,12,manifest.length],[136,12,0]])header.write(value.toString(8).padStart(size-1,'0')+'\0',at,size);
 header.fill(32,148,156);header[156]=48;header.write('ustar\0',257);header.write('00',263);
 header.write([...header].reduce((a,b)=>a+b,0).toString(8).padStart(6,'0')+'\0 ',148,8);
 return zlib.gzipSync(Buffer.concat([header,manifest,Buffer.alloc((512-manifest.length%512)%512+1024)]));
}
const archives=new Map(names.map(n=>[n,tarball(n)]));
let events=[],started=0n,delayA=0,delayC=0;const sockets=new Set();
const tlsServer=http2.createSecureServer({key:tls.key,cert:tls.cert,allowHTTP1:true});
tlsServer.on('request',async(req,res)=>{
 try {
  const key=requestKey(req);const parts=decodeURIComponent(req.url).slice(1).split('/');const name=parts[0];assert(names.includes(name));
  const archive=parts.includes('-');const event={name,kind:archive?'tarball':'metadata',request_ms:Number(process.hrtime.bigint()-started)/1e6};events.push(event);
  if(!archive)await new Promise(r=>setTimeout(r,name===names[0]?delayA:name===names[2]?delayC:0));
  const manifest={name,version:'1.0.0',dist:{tarball:`https://registry.npmjs.org/${name}/-/${name}-1.0.0.tgz`,integrity:'sha512-'+crypto.createHash('sha512').update(archives.get(name)).digest('base64')},...(name===names[1]?{dependencies:{[names[2]]:'1.0.0'}}:{})};
  const body=archive?archives.get(name):Buffer.from(JSON.stringify(parts.length>1?manifest:{name,versions:{'1.0.0':manifest},'dist-tags':{latest:'1.0.0'}}));
  res.writeHead(200,{'content-type':archive?'application/octet-stream':'application/json','content-length':body.length,'cache-control':'public, max-age=300'});res.end(body);
  event.response_ms=Number(process.hrtime.bigint()-started)/1e6;event.accept=key[2];
 }catch(e){res.writeHead(500);res.end(String(e));}
});
await new Promise(r=>tlsServer.listen(0,'127.0.0.1',r));
const proxy=http.createServer((req,res)=>{res.writeHead(403);res.end();});
proxy.on('connect',(req,client,head)=>{
 try{validateAuthority(req.url,true);}catch{client.destroy();return;}
 const upstream=net.connect(tlsServer.address().port,'127.0.0.1',()=>{client.write('HTTP/1.1 200 Connection Established\r\n\r\n');if(head.length)upstream.write(head);client.pipe(upstream);upstream.pipe(client);});
 for(const s of [client,upstream]){sockets.add(s);s.on('close',()=>sockets.delete(s));s.on('error',()=>{client.destroy();upstream.destroy();});}
});
await new Promise(r=>proxy.listen(0,'127.0.0.1',r));const proxyUrl=`http://127.0.0.1:${proxy.address().port}`;
const rows=[],plan={rounds:12,delays:[{a:0,c:150},{a:150,c:150}],order:'AB/BA alternation; reverse delay order each round; two unscored warm gates per binary',binaries:Object.fromEntries(Object.entries(binaries).map(([v,p])=>[v,{path:p,sha256:sha(fs.readFileSync(p))}]))};
fs.writeFileSync(path.join(root,'plan.json'),JSON.stringify(plan,null,2));
try{
 for(let sample=-1;sample<=12;sample++)for(const delays of (sample%2?plan.delays:[...plan.delays].reverse()))for(const variant of (sample%2?['baseline','candidate']:['candidate','baseline'])){
  delayA=delays.a;delayC=delays.c;const work=path.join(root,'work');fs.rmSync(work,{recursive:true,force:true});fs.mkdirSync(path.join(work,'home'),{recursive:true});fs.mkdirSync(path.join(work,'project'));
  fs.writeFileSync(path.join(work,'home','.npmrc'),`//registry.npmjs.org/:cafile=${tls.ca}\n`);
  fs.writeFileSync(path.join(work,'project','package.json'),JSON.stringify({name:'lookahead-probe',version:'1.0.0',dependencies:{[names[0]]:'1.0.0',[names[1]]:'1.0.0'}}));
  const out=path.join(root,`${sample}-${delayA}-${variant}`);fs.mkdirSync(out);
  const env=Object.fromEntries(['PATH','TMPDIR','LANG','SHELL'].filter(k=>process.env[k]).map(k=>[k,process.env[k]]));
  Object.assign(env,{HOME:path.join(work,'home'),LPM_HOME:path.join(work,'lpm-home'),CI:'1',RUST_LOG:'off',LPM_NPM_ROUTE:'direct',LPM_TYPOSQUAT_GUARD:'0',HTTPS_PROXY:proxyUrl,HTTP_PROXY:proxyUrl,NO_PROXY:''});
  if(sample===0)env.LPM_INSTALL_TIMELINE_DIR=path.join(out,'traces');
  events=[];started=process.hrtime.bigint();
  const child=spawn('/usr/bin/time',['-l',binaries[variant],'--json','install','--no-frozen-lockfile','--no-skills','--no-editor-setup','--no-security-summary'],{cwd:path.join(work,'project'),env});
  let stdout='',stderr='';child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);
  const timeout=setTimeout(()=>child.kill('SIGKILL'),20000);const code=await new Promise((r,j)=>{child.on('exit',r);child.on('error',j)});clearTimeout(timeout);
  const wallMs=Number(process.hrtime.bigint()-started)/1e6;
  fs.writeFileSync(path.join(out,'stdout.json'),stdout);fs.writeFileSync(path.join(out,'stderr.txt'),stderr);
  assert.equal(code,0,stderr+stdout);assert.equal(JSON.parse(stdout).success,true);
  const lock=fs.readFileSync(path.join(work,'project','lpm.lock'));fs.writeFileSync(path.join(out,'lpm.lock'),lock);
  const objects=path.join(work,'lpm-home','store','v2','objects');const digests=Object.fromEntries(fs.readdirSync(objects).filter(n=>n.startsWith('sha')).sort().map(n=>[n,fs.readFileSync(path.join(objects,n,'.lpm-object-integrity'),'utf8').trim()]));
  const row={sample,variant,delayA,delayC,wallMs,peakRssBytes:Number(stderr.match(/(\d+)\s+maximum resident set size/)[1]),events:[...events],lockSha:sha(lock),digests};rows.push(row);fs.writeFileSync(path.join(root,'rows.json'),JSON.stringify(rows,null,2));
  console.log(sample,delayA,variant,wallMs.toFixed(1),events.filter(e=>e.kind==='metadata').map(e=>`${e.name}:${e.request_ms.toFixed(1)}-${e.response_ms.toFixed(1)}`).join(' '));
 }
 const scored=rows.filter(r=>r.sample>0);assert.equal(new Set(rows.map(r=>r.lockSha)).size,1);assert.equal(new Set(rows.map(r=>JSON.stringify(r.digests))).size,1);
 const median=a=>{a.sort((a,b)=>a-b);return(a[(a.length-1)>>1]+a[a.length>>1])/2;};
 const summary=plan.delays.map(({a})=>({delayA:a,variants:Object.fromEntries(Object.keys(binaries).map(v=>{const s=scored.filter(r=>r.delayA===a&&r.variant===v);return[v,{medianMs:median(s.map(r=>r.wallMs)),medianRssMiB:median(s.map(r=>r.peakRssBytes))/1024**2,metadataRequests:s.map(r=>r.events.filter(e=>e.kind==='metadata').length)}]}))}));
 fs.writeFileSync(path.join(root,'summary.json'),JSON.stringify(summary,null,2));console.log(summary);
}finally{for(const s of sockets)s.destroy();proxy.close();tlsServer.close();tls.close();}
