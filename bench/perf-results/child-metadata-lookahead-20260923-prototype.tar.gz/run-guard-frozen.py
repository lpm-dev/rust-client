from pathlib import Path
import subprocess,json,sys
root=Path('/tmp/lpm-metadata-lookahead')
plan=json.loads((root/'guard-validation-plan.json').read_text())
for cohort in plan['frozen']:
 fixture,stage,samples=cohort['fixture'],cohort['stage'],cohort['samples_per_variant']
 with (root/f'{fixture}-{stage}.log').open('w') as log:
  p=subprocess.run(['node',str(root/'run-frozen-guard.mjs'),fixture,stage,str(samples)],stdout=log,stderr=subprocess.STDOUT)
 print(fixture,'runner',p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 p=subprocess.run(['python3',str(root/'analyze-frozen.py'),str(root/f'{fixture}-{stage}')])
 if p.returncode:raise SystemExit(p.returncode)
