import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createReplayProxy} from '/Users/tolga/.codex/worktrees/install-overhead/rust-client/bench/scripts/cold-object-finalization-replay/replay-proxy.mjs';
import {benchmarkTls} from '/Users/tolga/.codex/worktrees/install-overhead/rust-client/bench/scripts/cold-object-finalization-replay/tls.mjs';
const [fixture,stage,rounds='12']=process.argv.slice(2);
const repo='/Users/tolga/.codex/worktrees/install-overhead/rust-client';
const definitions={
 nest:['bench/audit-fixtures/peer-heavy/nestjs-deep','@nestjs/core/package.json','/tmp/lpm-cold-nest-isolation/frozen-registry'],
 vite:['bench/audit-fixtures/peer-heavy/vite-react','react/package.json','/tmp/lpm-next-install-costs/memory-vite-frozen/frozen-registry'],
 sharp:['bench/audit-fixtures/native/sharp-image','sharp/package.json','/tmp/lpm-metadata-lookahead/frozen-sharp-complete'],
 t3:['bench/audit-fixtures/t3-install','next/package.json','/tmp/lpm-metadata-lookahead/frozen-t3'],
};
const [fixturePath,verifyModule,directory]=definitions[fixture];
const root=`/tmp/lpm-metadata-lookahead/${fixture}-${stage}`;assert(!fs.existsSync(root));fs.mkdirSync(root);
const tls=benchmarkTls(root);
const expectedManifestSha256=crypto.createHash('sha256').update(fs.readFileSync(path.join(directory,'manifest.json'))).digest('hex');
const proxy=await createReplayProxy({...tls,directory,expectedManifestSha256}).catch(e=>{tls.close();throw e});
try{
 const variants=[
  {id:'baseline',manager:'lpm',binary:'/tmp/lpm-next-install-costs/lpm-timeline'},
  {id:'candidate',manager:'lpm',binary:'/tmp/lpm-metadata-lookahead/lpm-lookahead-guard'},
  {id:'bun',manager:'bun',binary:'/Users/tolga/.bun/bin/bun'},
 ];
 const config={output:path.join(root,'runs'),samples:Number(rounds),diagnostics:2,states:['first-install'],variants,
  balancedOrders:true,sharedLpmRoot:true,keepWork:true,fixture:path.join(repo,fixturePath),verifyModule,
  registry:proxy.url,ca:tls.ca,expectedManifestSha256,diagnosticTimelineRoot:path.join(root,'traces')};
 fs.writeFileSync(path.join(root,'config.json'),JSON.stringify(config,null,2));
 const log=fs.openSync(path.join(root,'runner.log'),'w');
 const child=spawn(process.execPath,['/tmp/lpm-metadata-lookahead/replay-runner.mjs',path.join(root,'config.json')],{cwd:repo,stdio:['ignore',log,log]});
 const code=await new Promise((r,j)=>{child.on('exit',r);child.on('error',j)});fs.closeSync(log);
 const status=proxy.status();fs.writeFileSync(path.join(root,'status.json'),JSON.stringify({code,...status},null,2));
 assert.equal(code,0,`runner exit ${code}: ${fs.readFileSync(path.join(root,'runner.log'),'utf8').slice(-3000)}`);
 assert.equal(status.upstreamRequests,0);assert.equal(status.misses.length,0);assert.equal(status.rejected.length,0);
 console.log('completed',root);
}finally{await proxy.close();tls.close();}
