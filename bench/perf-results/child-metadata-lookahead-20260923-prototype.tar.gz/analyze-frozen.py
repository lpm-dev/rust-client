import sys, json, math, statistics, hashlib
from pathlib import Path
root=Path(sys.argv[1]); runs=root/'runs'
rows=json.loads((runs/'rows.json').read_text())
status=json.loads((root/'status.json').read_text())
assert status['code']==0 and status['upstreamRequests']==0 and not status['misses'] and not status['rejected']
def percentile(values,q):
 return sorted(values)[math.ceil(len(values)*q)-1]
def stats(values):
 return dict(n=len(values),median=statistics.median(values),p95=percentile(values,.95),minimum=min(values),maximum=max(values))
groups={v:[r for r in rows if r['variant']==v] for v in ['baseline','candidate','bun']}
summary={'variants':{},'parity':{},'paired':{}}
diagnostics=[]
for p in (runs/'artifacts/timing').glob('**/timeline/*.json'):
 trace=json.loads(p.read_text())
 backoffs=sum(r['name']=='backoff_start' for r in trace['records'])
 diagnostics.append({'path':str(p.relative_to(root)),'backoffs':backoffs,'dropped_records':trace['dropped_records']})
 assert backoffs==0,('unexpected replay transport backoff',str(p),backoffs)
summary['diagnostics']=diagnostics
reference=None
for variant,group in groups.items():
 for row in group:
  assert row['ok'] and row['verification']['ok']
  p=runs/'artifacts'/row['scenario']/variant/str(row['sample'])
  if variant!='bun':
   values={name:hashlib.sha256((p/name).read_bytes()).hexdigest() for name in ['lpm.lock','selected-packages.json','object-content-digests.json','independent-payload-digests.json']}
   if reference is None: reference=values
   assert values==reference,(variant,row['sample'],'output parity failed')
  requests=[e for e in status['events'] if e['phase']==f"sample-{row['sample']}-{variant}"]
  row['metadata_requests']=sum('/-/' not in e['request'][1] for e in requests)
  row['metadata_bytes']=sum(e['bytes'] for e in requests if '/-/' not in e['request'][1])
  row['tarball_requests']=sum('/-/' in e['request'][1] for e in requests)
 summary['variants'][variant]={metric:stats([r[metric] for r in group]) for metric in ['wall_ms','max_rss_bytes','metadata_requests','metadata_bytes','tarball_requests']}
for metric in ['wall_ms','max_rss_bytes','metadata_requests','metadata_bytes']:
 paired=[next(r[metric] for r in groups['candidate'] if r['sample']==b['sample'])-b[metric] for b in groups['baseline']]
 summary['paired'][metric]=stats(paired)
 summary['paired'][metric].update(faster=sum(x<0 for x in paired),tied=sum(x==0 for x in paired),slower=sum(x>0 for x in paired))
summary['parity']['all_lpm_samples_identical']=True
summary['parity']['sha256']=reference
for sample in sorted({r['sample'] for r in rows}):
 p=runs/'artifacts'/'first-install'
 a=json.loads((p/'candidate'/str(sample)/'independent-payload-digests.json').read_text())
 b=json.loads((p/'bun'/str(sample)/'independent-payload-digests.json').read_text())
 assert a.keys()==b.keys(),('cross-manager selected packages',a.keys()-b.keys(),b.keys()-a.keys())
 assert all(a[k]['contentDigest']==b[k]['contentDigest'] for k in a),('cross-manager content mismatch',sample)
summary['parity']['all_cross_manager_package_payload_bytes_equal']=True
(root/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
print(root)
for v,m in summary['variants'].items():print(v,'wall',m['wall_ms'],'RSS MiB',m['max_rss_bytes']['median']/2**20,'metadata',m['metadata_requests'])
print('paired candidate-minus-baseline',summary['paired']['wall_ms'])
