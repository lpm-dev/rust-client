#!/bin/bash
set -u
ROOT=/Users/tolga/Documents/Projects/lpm-dev/performance-runs/20260925/npm-token
for name in shaped-t3 fast-t3; do
  echo "$(date '+%H:%M:%S') start $name"
  if ! node "$ROOT/$name/run.mjs" --preflight > "$ROOT/$name-preflight.out" 2>&1; then
    echo "$(date '+%H:%M:%S') PREFLIGHT FAILED $name"; tail -5 "$ROOT/$name-preflight.out"; continue
  fi
  if ! node "$ROOT/$name/run.mjs" > "$ROOT/$name-scored.out" 2>&1; then
    echo "$(date '+%H:%M:%S') SCORED FAILED $name"; tail -5 "$ROOT/$name-scored.out"; continue
  fi
  echo "$(date '+%H:%M:%S') done $name"
done
echo "$(date '+%H:%M:%S') all done"
