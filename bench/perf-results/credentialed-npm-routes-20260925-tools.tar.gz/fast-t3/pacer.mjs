import { performance } from 'node:perf_hooks';

export class PayloadPacer {
  constructor({ bytesPerSecond, responseLatencyMs, quantumBytes = 16384, burstBytes = 65536,
    now = () => performance.now(), setTimer = setTimeout, clearTimer = clearTimeout,
    onWrite = () => {} }) {
    if (!(Number.isFinite(bytesPerSecond) && bytesPerSecond > 0
      && Number.isFinite(responseLatencyMs) && responseLatencyMs >= 0
      && Number.isSafeInteger(quantumBytes) && quantumBytes > 0
      && Number.isSafeInteger(burstBytes) && burstBytes >= quantumBytes)) {
      throw new Error('invalid pacing profile');
    }
    this.profile = { bytesPerSecond, responseLatencyMs, quantumBytes, burstBytes };
    this.now = now; this.setTimer = setTimer; this.clearTimer = clearTimer; this.onWrite = onWrite;
    this.tokens = burstBytes; this.updated = now(); this.queue = []; this.entries = new Set(); this.timer = undefined;
    this.closed = false; this.pumping = false;
    this.totals = { scheduledBytes: 0, completed: 0, cancelled: 0, maximumActive: 0,
      maximumTimerLatenessMs: 0, backpressureEvents: 0, transportErrors: 0 };
  }

  status() { return { profile: this.profile, active: this.entries.size, queued: this.queue.length, ...this.totals }; }

  send(response, body, status, headers, received = this.now()) {
    if (this.closed || this.entries.size >= 2048) throw new Error('pacing queue unavailable');
    const entry = { response, body, status, headers, offset: 0, eligible: received + this.profile.responseLatencyMs,
      opened: false, blocked: false, done: false, drainAt: undefined,
      stats: { receivedMs: received, headerMs: undefined, firstBodyMs: undefined,
        lastBodyMs: undefined, scheduledBytes: 0, backpressureMs: 0 } };
    entry.drain = () => {
      if (entry.done || !entry.blocked) return;
      entry.stats.backpressureMs += Math.max(0, this.now() - entry.drainAt);
      entry.blocked = false; entry.drainAt = undefined; this.pump();
    };
    entry.close = () => this.remove(entry, true);
    entry.error = () => this.remove(entry, true);
    entry.finish = () => this.remove(entry, entry.offset !== entry.body.length);
    response.on('drain', entry.drain);
    response.on('close', entry.close);
    response.on('error', entry.error);
    response.on('finish', entry.finish);
    this.entries.add(entry);
    this.queue.push(entry);
    this.totals.maximumActive = Math.max(this.totals.maximumActive, this.entries.size);
    this.pump();
    return entry.stats;
  }

  remove(entry, cancelled) {
    if (entry.done) return;
    entry.done = true;
    entry.response.off('drain', entry.drain);
    entry.response.off('close', entry.close);
    entry.response.off('error', entry.error);
    entry.response.off('finish', entry.finish);
    this.entries.delete(entry);
    this.queue = this.queue.filter(item => item !== entry);
    if (cancelled) this.totals.cancelled += 1;
    else this.totals.completed += 1;
    if (!this.queue.length && this.timer !== undefined) {
      this.clearTimer(this.timer); this.timer = undefined;
    }
  }

  refill() {
    const now = this.now();
    this.tokens = Math.min(this.profile.burstBytes,
      this.tokens + Math.max(0, now - this.updated) * this.profile.bytesPerSecond / 1000);
    this.updated = now;
    return now;
  }

  pump() {
    if (this.closed || this.pumping) return;
    this.pumping = true;
    if (this.timer !== undefined) { this.clearTimer(this.timer); this.timer = undefined; }
    try {
      let visitedWithoutWrite = 0;
      while (this.queue.length && visitedWithoutWrite < this.queue.length) {
        const entry = this.queue.shift();
        this.queue.push(entry);
        if (entry.done || entry.response.destroyed) { this.remove(entry, true); continue; }
        let now = this.refill();
        if (entry.eligible > now || entry.blocked) { visitedWithoutWrite += 1; continue; }
        try {
          if (!entry.opened) {
            entry.response.writeHead(entry.status, entry.headers);
            entry.response.flushHeaders();
            entry.opened = true; entry.stats.headerMs = this.now();
          }
          const amount = Math.min(this.profile.quantumBytes, entry.body.length - entry.offset);
          if (amount === 0) {
            this.queue = this.queue.filter(item => item !== entry);
            entry.response.end(); visitedWithoutWrite = 0; continue;
          }
          now = this.refill();
          if (this.tokens < amount) { visitedWithoutWrite += 1; continue; }
          this.tokens -= amount;
          const chunk = entry.body.subarray(entry.offset, entry.offset + amount);
          entry.offset += amount;
          entry.stats.firstBodyMs ??= now; entry.stats.lastBodyMs = now;
          entry.stats.scheduledBytes += amount; this.totals.scheduledBytes += amount;
          this.onWrite({ at: now, bytes: amount });
          const writable = entry.response.write(chunk);
          visitedWithoutWrite = 0;
          if (entry.offset === entry.body.length) {
            this.queue = this.queue.filter(item => item !== entry);
            entry.response.end();
          } else if (!writable) {
            entry.blocked = true; entry.drainAt = now; this.totals.backpressureEvents += 1;
          }
        } catch {
          this.totals.transportErrors += 1;
          this.remove(entry, true);
          entry.response.destroy();
          visitedWithoutWrite = 0;
        }
      }
      const now = this.refill();
      let delay = Infinity;
      for (const entry of this.queue) {
        if (entry.blocked) continue;
        if (!entry.opened && entry.eligible > now) delay = Math.min(delay, entry.eligible - now);
        else {
          const amount = Math.min(this.profile.quantumBytes, entry.body.length - entry.offset);
          delay = Math.min(delay, Math.max(0, amount - this.tokens) * 1000 / this.profile.bytesPerSecond);
        }
      }
      if (Number.isFinite(delay)) {
        delay = Math.max(1, Math.ceil(delay));
        const due = now + delay;
        this.timer = this.setTimer(() => {
          this.timer = undefined;
          this.totals.maximumTimerLatenessMs = Math.max(this.totals.maximumTimerLatenessMs, this.now() - due);
          this.pump();
        }, delay);
      }
    } finally { this.pumping = false; }
  }

  close() {
    this.closed = true;
    if (this.timer !== undefined) this.clearTimer(this.timer);
    this.timer = undefined;
    for (const entry of [...this.entries]) {
      this.remove(entry, true); entry.response.destroy();
    }
  }
}
