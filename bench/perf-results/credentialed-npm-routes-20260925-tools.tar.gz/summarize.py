"""Summarize the credentialed-npm harnesses: nearest-rank medians/p95, paired deltas,
installed-tree parity, and which scored registry requests carried the bench token."""
import glob
import hashlib
import json
import os
import statistics
import sys

ROOT = "/Users/tolga/Documents/Projects/lpm-dev/performance-runs/20260925/npm-token"
REFERENCE = "token-888"


def nearest_rank(values, percentile):
    ordered = sorted(values)
    rank = max(1, -(-len(ordered) * percentile // 100))
    return ordered[int(rank) - 1]


def digest(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()[:16] if os.path.exists(path) else None


def summarize(name):
    directory = os.path.join(ROOT, name)
    rows = json.load(open(os.path.join(directory, "scored", "rows.json")))
    result = {"fixture": name, "failed": sum(not row.get("ok") for row in rows), "variants": {}}
    by_variant = {}
    for row in rows:
        if row.get("ok"):
            by_variant.setdefault(row["variant"], {})[row["sample"]] = row
    for variant, samples in by_variant.items():
        walls = [row["wall_ms"] for row in samples.values()]
        entry = {
            "n": len(walls),
            "median_ms": round(statistics.median(walls), 1),
            "p95_ms": round(nearest_rank(walls, 95), 1),
        }
        if variant != REFERENCE and REFERENCE in by_variant:
            pairs = [
                samples[sample]["wall_ms"] - by_variant[REFERENCE][sample]["wall_ms"]
                for sample in samples
                if sample in by_variant[REFERENCE]
            ]
            entry[f"paired_vs_{REFERENCE}_ms"] = round(statistics.median(pairs), 1)
            entry[f"faster_than_{REFERENCE}"] = f"{sum(delta < 0 for delta in pairs)}/{len(pairs)}"
        result["variants"][variant] = entry
    parity = {
        variant: sorted({
            (digest(os.path.join(path, "selected-packages.json")), digest(os.path.join(path, "object-content-digests.json")))
            for path in glob.glob(os.path.join(directory, "scored", "artifacts", "first-install", variant, "*"))
        })
        for variant in by_variant
    }
    result["parity_identical"] = len({tuple(value) for value in parity.values()}) == 1 and all(len(value) == 1 for value in parity.values())
    status = json.load(open(os.path.join(directory, "scored", "registry-status.json")))
    requests = {}
    for event in status["events"]:
        phase = event["phase"]
        if not phase.startswith("sample-first-install-"):
            continue
        variant = phase.rsplit("-", 2)[-2] + "-" + phase.rsplit("-", 2)[-1]
        counts = requests.setdefault(variant, {"requests": 0, "authorized": 0, "metadata": 0, "latest": 0, "abbreviated": 0})
        counts["requests"] += 1
        counts["authorized"] += bool(event.get("authorized"))
        target, accept = event["request"][1], event["request"][2]
        if "/-/" not in target:
            counts["metadata"] += 1
            counts["latest"] += target.endswith("/latest")
            counts["abbreviated"] += "install-v1" in accept
    result["requests_per_variant"] = requests
    return result


if __name__ == "__main__":
    for name in sys.argv[1:] or ["shaped-t3", "fast-t3"]:
        summary = summarize(name)
        json.dump(summary, open(os.path.join(ROOT, name, "summary.json"), "w"), indent=2)
        print(json.dumps(summary, indent=2))
