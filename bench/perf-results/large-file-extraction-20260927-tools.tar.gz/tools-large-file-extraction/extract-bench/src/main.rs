#[global_allocator]
static GLOBAL: mimalloc::MiMalloc = mimalloc::MiMalloc;
use std::time::Instant;
fn main() {
    let args: Vec<String> = std::env::args().collect();
    let (tgz, scratch, reps) = (&args[1], std::path::PathBuf::from(&args[2]), args[3].parse::<usize>().unwrap());
    for rep in 0..reps {
        let target = scratch.join(format!("x{rep}"));
        let _ = std::fs::remove_dir_all(&target);
        std::fs::create_dir_all(&target).unwrap();
        let started = Instant::now();
        let files = lpm_extractor::extract_tarball_from_reader_pipelined_digests(std::fs::File::open(tgz).unwrap(), &target, || {}).unwrap().len();
        let elapsed = started.elapsed().as_secs_f64() * 1e3;
        println!("rep={rep} files={files} total={elapsed:.1} {}", lpm_extractor::take_extract_stats());
        std::fs::remove_dir_all(&target).unwrap();
    }
}
