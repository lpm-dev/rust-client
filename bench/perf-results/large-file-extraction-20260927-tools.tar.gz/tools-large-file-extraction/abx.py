"""Alternate extraction-bench variants in rotating order and report medians.

Usage: abx.py <bench-binary> <tarball> <scratch-dir> <rounds> <reps> name=ENV=V,ENV=V ...
"""
import os, statistics, subprocess, sys

binary, tarball, scratch, rounds, reps = sys.argv[1:6]
variants = []
for spec in sys.argv[6:]:
    name, _, env = spec.partition("=")
    variants.append((name, dict(kv.split("=", 1) for kv in env.split(",") if kv)))
samples = {name: [] for name, _ in variants}
for round_index in range(int(rounds)):
    order = variants[round_index % len(variants):] + variants[:round_index % len(variants)]
    for name, env in order:
        out = subprocess.run([binary, tarball, scratch, reps], env={**os.environ, **env},
                             capture_output=True, text=True, check=True).stdout
        for line in out.splitlines():
            total = next(kv for kv in line.split() if kv.startswith("total="))
            samples[name].append(float(total[6:]))
base = statistics.median(samples[variants[0][0]])
for name, _ in variants:
    values = sorted(samples[name])
    median = statistics.median(values)
    print(f"{name:10} median {median:7.1f}  p10 {values[len(values)//10]:7.1f}  p90 {values[len(values)*9//10]:7.1f}  vs {variants[0][0]} {median-base:+6.1f}  n={len(values)}")
