"""Paired wall-time comparison of `lpm run` for two binaries.

Usage: runbench.py <base-binary> <change-binary> <runs>
The project declares engines.node, and its script does not start Node, so the
difference is the engine check's Node version lookup.
"""

import json
import os
import statistics
import subprocess
import sys
import tempfile
import time

base, change, runs = sys.argv[1], sys.argv[2], int(sys.argv[3])
work = tempfile.mkdtemp(prefix="lpm-runbench-")
project = os.path.join(work, "project")
os.makedirs(project)
with open(os.path.join(project, "package.json"), "w") as handle:
    json.dump(
        {
            "name": "runbench",
            "version": "1.0.0",
            "engines": {"node": ">=18"},
            "scripts": {"hello": "true"},
        },
        handle,
    )


def run(binary, home):
    env = dict(os.environ, HOME=home, LPM_HOME=os.path.join(home, ".lpm"), CI="1", NO_COLOR="1")
    start = time.perf_counter()
    subprocess.run([binary, "run", "hello"], cwd=project, env=env, check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return (time.perf_counter() - start) * 1e3


homes = {}
for label, binary in (("base", base), ("change", change)):
    homes[label] = os.path.join(work, f"home-{label}")
    os.makedirs(homes[label])
    run(binary, homes[label])

samples = {"base": [], "change": []}
for index in range(runs):
    order = (("base", base), ("change", change))
    if index % 2:
        order = order[::-1]
    for label, binary in order:
        samples[label].append(run(binary, homes[label]))

deltas = [c - b for b, c in zip(samples["base"], samples["change"])]
print(f"base   median {statistics.median(samples['base']):6.2f} ms")
print(f"change median {statistics.median(samples['change']):6.2f} ms")
print(f"paired median {statistics.median(deltas):+6.2f} ms ({sum(d < 0 for d in deltas)}/{len(deltas)} faster)")
recorded = os.path.join(homes["change"], ".lpm", "cache", "metadata", "node-versions")
print("recorded versions:", sorted(os.listdir(recorded)) if os.path.isdir(recorded) else "none")
