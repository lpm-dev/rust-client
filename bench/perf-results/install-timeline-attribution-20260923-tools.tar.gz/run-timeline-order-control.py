import json,pathlib,subprocess,time,hashlib,sys,shutil
root=pathlib.Path('/tmp/lpm-next-install-costs');name=sys.argv[1]
assert name in ['same-binary','reversed-labels']
assert shutil.disk_usage('/tmp').free>=10*1024**3
cmd=json.loads((root/'timeline-final-benchmark-status.json').read_text())[-1]['command'].copy()
paths={'baseline':root/'lpm-known-size','candidate':root/'lpm-known-size'} if name=='same-binary' else {'baseline':root/'lpm-timeline','candidate':root/'lpm-known-size'}
for label,p in paths.items():
 for i,arg in enumerate(cmd):
  if arg.startswith(label+'='):cmd[i]=label+'='+str(p)
output=root/('timeline-readiness-'+name)
assert not output.exists()
cmd[cmd.index('--output')+1]=str(output)
record=dict(name=name,command=cmd,binaries={label:dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for label,p in paths.items()},reason='Diagnose the repeated live Sharp difference with identical binaries, then exchange binary labels while preserving the preselected 12-round four-fixture matrix and execution order.')
(root/('timeline-order-'+name+'-plan.json')).write_text(json.dumps(record,indent=2))
start=time.time()
with (root/('timeline-order-'+name+'.log')).open('w') as log:rc=subprocess.run(cmd,cwd='/Users/tolga/.codex/worktrees/install-overhead/rust-client',stdout=log,stderr=subprocess.STDOUT).returncode
record.update(returncode=rc,seconds=time.time()-start)
(root/('timeline-order-'+name+'-status.json')).write_text(json.dumps(record,indent=2))
print(name,'finished',rc,flush=True)
raise SystemExit(rc)
