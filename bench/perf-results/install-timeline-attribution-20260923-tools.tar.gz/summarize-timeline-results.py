import pathlib,json,statistics,math,collections,hashlib
R=pathlib.Path('/tmp/lpm-next-install-costs')
def stats(values):
 if not values:return None
 v=sorted(values);return dict(n=len(v),median=statistics.median(v),p95=v[math.ceil(.95*len(v))-1],min=v[0],max=v[-1])
result={'cohorts':{},'parity':{},'paired':{}}
for cohort in ['timeline-nest-frozen/scored','timeline-vite-frozen/scored','timeline-live-nest','timeline-live-t3','timeline-sharp-frozen/scored','timeline-live-sharp-confirmation','timeline-readiness-warmup','timeline-readiness-scored','timeline-nest-final/scored','timeline-vite-final/scored','timeline-sharp-final/scored','timeline-live-nest-final','timeline-live-t3-final','timeline-readiness-warmup-final','timeline-readiness-scored-final','timeline-readiness-same-binary','timeline-readiness-reversed-labels']:
 path=R/cohort/'rows.json'
 if not path.exists():continue
 rows=json.loads(path.read_text());groups=collections.defaultdict(list)
 for x in rows:
  key='/'.join([x.get('fixture',x.get('scenario','')),x.get('mode',''),x.get('variant',x.get('binary') or x['manager'])])
  groups[key].append(x)
 result['cohorts'][cohort]={key:dict(wall_ms=stats([x['wall_ms'] for x in xs]),rss_mib=stats([x['max_rss_bytes']/1048576 for x in xs if x.get('max_rss_bytes')]),successful=sum(x['exit_code']==0 for x in xs),rows=len(xs)) for key,xs in groups.items()}
 if cohort.endswith('/scored'):
  for a,b in [('baseline','disabled'),('disabled','enabled')]:
   left={x['sample']:x for x in rows if x['variant']==a};right={x['sample']:x for x in rows if x['variant']==b}
   result['paired'][cohort+'/'+a+':'+b]=dict(wall_delta_ms=stats([right[n]['wall_ms']-x['wall_ms'] for n,x in left.items()]),rss_delta_mib=stats([(right[n]['max_rss_bytes']-x['max_rss_bytes'])/1048576 for n,x in left.items()]),candidate_faster=sum(right[n]['wall_ms']<x['wall_ms'] for n,x in left.items()))
  result['parity'][cohort]={}
  for name in ['lpm.lock','selected-packages.json','object-content-digests.json']:
   paths=[R/cohort/'artifacts'/x['scenario']/x['variant']/str(x['sample'])/name for x in rows]
   digests=collections.Counter(hashlib.sha256(p.read_bytes()).hexdigest() for p in paths)
   result['parity'][cohort][name]={'unique':len(digests),'sha256_counts':dict(digests)}
   assert len(digests)==1,(cohort,name,dict(digests))
(R/'timeline-summary.json').write_text(json.dumps(result,indent=2)+'\n')
for cohort,groups in result['cohorts'].items():
 print(cohort)
 for key,value in groups.items():print(key,'wall median/p95',value['wall_ms']['median'],value['wall_ms']['p95'],'RSS',round(value['rss_mib']['median'],2))
print('parity',result['parity']);print('paired',result['paired'])
