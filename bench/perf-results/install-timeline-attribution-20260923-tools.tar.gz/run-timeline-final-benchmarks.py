import json,pathlib,subprocess,time,shutil,hashlib
r=pathlib.Path('/tmp/lpm-next-install-costs');repo=pathlib.Path('/Users/tolga/.codex/worktrees/install-overhead/rust-client');results=[]
assert 'Finished `release`' in (r/'timeline-release-verified.log').read_text()
gates=json.loads((r/'timeline-gates/gates.json').read_text());latest={x['name']:x['returncode'] for x in gates};assert len(latest)==9 and all(x==0 for x in latest.values()),latest
shutil.copy2('/tmp/lpm-timeline-release-1940/release/lpm-rs',r/'lpm-timeline')
(r/'timeline-binary.json').write_text(json.dumps(dict(sha256=hashlib.sha256((r/'lpm-timeline').read_bytes()).hexdigest(),commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),parent='6a1b158987a890102ef3b814864fcd427715edef'),indent=2))
steps=[(f'frozen-{fixture}',['node',str(r/f'run-timeline-{fixture}-final.mjs')]) for fixture in ['nest','vite','sharp']]
steps += [(f'live-{fixture}',['node',str(r/'timeline-live-runner.mjs'),str(r/f'timeline-live-{fixture}-final-config.json')]) for fixture in ['nest','t3']]
base=['node','bench/scripts/run-install-readiness.mjs','--fixtures','vite-react,native-sharp,nest,t3='+str(repo/'bench/audit-fixtures/t3-install'),'--managers','lpm,bun','--lpm-routes','direct','--lpm-firewall-modes','off','--lpm-binary','baseline='+str(r/'lpm-known-size'),'--lpm-binary','candidate='+str(r/'lpm-timeline'),'--lpm-compare','baseline:candidate','--allow-inconclusive','--modes','cold,warm,up-to-date']
steps += [(f'readiness-{phase}',base+['--samples',str(n),'--output',str(r/f'timeline-readiness-{phase}-final')]) for phase,n in [('warmup',1),('scored',12)]]
for name,cmd in steps:
 assert shutil.disk_usage('/tmp').free>=10*1024**3
 print('starting',name,flush=True);start=time.time()
 with (r/f'timeline-final-bench-{name}.log').open('w') as log:rc=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT).returncode
 results.append(dict(name=name,command=cmd,returncode=rc,seconds=time.time()-start));(r/'timeline-final-benchmark-status.json').write_text(json.dumps(results,indent=2));print('finished',name,rc,flush=True)
 if name.startswith('readiness-'):
  assert all(x['exit_code']==0 for x in json.loads((r/f'timeline-{name}-final/rows.json').read_text()))
 if rc:raise SystemExit(rc)
