import pathlib,re,tempfile,hashlib
for fixture in ['nest','vite']:
 source=pathlib.Path(f'/tmp/lpm-next-install-costs/run-timeline-{fixture}-frozen.mjs').read_text()
 anchor_variable=re.search(r"sha256: crypto.createHash\('sha256'\).update\(fs.readFileSync\(path.join\((\w+), 'frozen-registry/manifest.json'\)\)\)",source).group(1)
 capture_variable=re.search(r"directory: path.join\((\w+), 'frozen-registry'\)",source).group(1)
 with tempfile.TemporaryDirectory() as directory:
  roots={name:pathlib.Path(directory)/name for name in ['root','sourceRoot']}
  actual=roots[capture_variable]/'frozen-registry/manifest.json';actual.parent.mkdir(parents=True);actual.write_text('[]')
  pinned=roots[anchor_variable]/'frozen-registry/manifest.json'
  assert pinned.exists(),f'{fixture}: anchor reads {anchor_variable}, capture writes {capture_variable}'
  assert hashlib.sha256(pinned.read_bytes()).digest()==hashlib.sha256(actual.read_bytes()).digest()
print('both preparation anchors hash the actual capture directory')
