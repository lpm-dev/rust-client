import pathlib,json,collections,statistics,math
ROOT=pathlib.Path('/tmp/lpm-next-install-costs')
def stats(values):
 if not values:return None
 v=sorted(values);return dict(n=len(v),median=statistics.median(v),p95=v[math.ceil(.95*len(v))-1],maximum=v[-1])
def analyze(path):
 t=json.loads(path.read_text());records=t['records'];spans={x['id']:dict(x,end=None) for x in records if x['kind']=='span_open'};events=collections.defaultdict(list)
 for x in records:
  if x['kind']=='span_close' and x['id'] in spans:spans[x['id']]['end']=x['at_us']
  elif x['kind']=='event':events[x['parent']].append(x)
 for xs in events.values():xs.sort(key=lambda x:x['at_us'])
 result=dict(path=str(path),outcome=t['outcome'],cutoff_ms=t['cutoff_us']/1000,records=len(records),dropped_records=t['dropped_records'],dropped_correlations=t.get('dropped_correlations',0),open_spans=t['open_spans'])
 intervals=collections.defaultdict(list);longest_http=[]
 for id,s in spans.items():
  if s['end'] is not None:intervals['span_'+s['name']].append((s['end']-s['at_us'])/1000)
  es=events[id]
  for start,end,key in [('enqueue','work_start','blocking_queue'),('work_start','work_end','blocking_work'),('work_end','await_resume','async_resume'),('metadata_enqueued','metadata_task_start','metadata_dispatch_wait'),('metadata_task_finished','resolver_observed','metadata_observation_wait'),('resolver_observed','graph_commit_start','metadata_ordered_commit_wait'),('metadata_task_finished','graph_commit_start','metadata_commit_wait'),('graph_commit_start','graph_commit_end','graph_commit_work'),('tree_walk_start','tree_walk_end','tree_walk'),('sidecars_start','sidecars_end','sidecars'),('sri_write_start','sri_write_end','sri_write'),('rename_start','rename_end','rename'),('admission_start','admission_end','extract_admission')]:
   a=next((x for x in es if x['name']==start),None);b=next((x for x in es if x['name']==end and (a is None or x['at_us']>=a['at_us'])),None)
   if a and b:
    if key=='blocking_work' and s['name']=='metadata_parse' and s['fields'].get('blocking')==0:key='inline_parse_work'
    intervals[key].append((b['at_us']-a['at_us'])/1000)
    intervals[key+'__'+s['name']].append((b['at_us']-a['at_us'])/1000)
  if s['name']=='metadata_body':
   body_end=next((x for x in es if x['name']=='body_end'),None)
   if body_end:intervals['metadata_body_read'].append((body_end['at_us']-s['at_us'])/1000)
  if s['name']=='http_request':
   active=None
   for e in es:
    if e['name']=='request_attempt':active=e
    elif e['name'] in ('headers_observed','request_failed') and active:
     ms=(e['at_us']-active['at_us'])/1000;intervals['http_attempt_to_headers_or_error'].append(ms);longest_http.append(dict(id=id,parent=s['parent'],start_ms=active['at_us']/1000,end_ms=e['at_us']/1000,ms=ms,attempt=active['fields'].get('attempt'),status=e['fields'].get('status')));active=None
 result['attribution_eligible']=not (result['dropped_records'] or result['dropped_correlations'])
 result['censored_spans']=[dict(id=id,name=s['name'],start_ms=s['at_us']/1000,observed_minimum_ms=(max([s['at_us']]+[e['at_us'] for e in events[id]])-s['at_us'])/1000) for id,s in spans.items() if s['end'] is None]
 result['censored_span_count']=len(result['censored_spans'])
 result['intervals']={k:dict(**stats(v),sum=sum(v)) for k,v in intervals.items()} if result['attribution_eligible'] else {}
 result['longest_http_attempts']=sorted(longest_http,key=lambda x:x['ms'],reverse=True)[:5] if result['attribution_eligible'] else []
 # Span ancestry lets separate decoder/input intervals be inspected without assigning package labels.
 def reaches_install(span):
  seen=set()
  while span is not None and span['id'] not in seen:
   if span['name']=='install_pipeline':return True
   seen.add(span['id']);span=spans.get(span['parent'])
  return False
 fetches=[s for s in spans.values() if s['name']=='tarball_fetch']
 result['unparented_tarball_fetches']=sum(s['parent'] is None for s in fetches)
 result['unrooted_tarball_fetches']=sum(not reaches_install(s) for s in fetches)
 result['fetch_ancestry_complete']=result['unrooted_tarball_fetches']==0
 if not result['fetch_ancestry_complete']:
  result['attribution_eligible']=False;result['intervals']={};result['longest_http_attempts']=[]
 return result
out=[]
for cohort in ['timeline-nest-frozen/scored','timeline-vite-frozen/scored','timeline-live-nest','timeline-live-t3','timeline-sharp-frozen/scored','timeline-nest-final/scored','timeline-vite-final/scored','timeline-sharp-final/scored','timeline-live-nest-final','timeline-live-t3-final']:
 root=ROOT/cohort
 if not (root/'rows.json').exists():continue
 for row in json.loads((root/'rows.json').read_text()):
  if row['variant']!='enabled':continue
  paths=list((root/'artifacts'/row['scenario']/row['variant']/str(row['sample'])/'timeline').glob('install-*.json'));assert len(paths)==1,(cohort,row['sample'],paths)
  a=analyze(paths[0]);a.update(cohort=cohort,sample=row['sample'],wall_ms=row['wall_ms'],max_rss_bytes=row['max_rss_bytes']);out.append(a)
(ROOT/'timeline-analysis.json').write_text(json.dumps(out,indent=2))
for cohort in sorted({x['cohort'] for x in out}):
 xs=[x for x in out if x['cohort']==cohort];print(cohort,'wall',stats([x['wall_ms'] for x in xs]),'records',stats([x['records'] for x in xs]),'dropped',sum(x['dropped_records'] for x in xs))
 for x in sorted(xs,key=lambda x:x['wall_ms'],reverse=True)[:3]:
  if not x['attribution_eligible']:
   print(' sample',x['sample'],'ineligible for attribution: lost records/correlations or incomplete fetch ancestry');continue
  print(' sample',x['sample'],'wall',x['wall_ms'],'cutoff',x['cutoff_ms'],{k:x['intervals'].get(k,{}).get('maximum') for k in ['span_resolver','http_attempt_to_headers_or_error','blocking_queue','async_resume','metadata_commit_wait','span_tar_materialization','tree_walk','sidecars','rename']})
