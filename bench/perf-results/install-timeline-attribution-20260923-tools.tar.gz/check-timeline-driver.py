import json,pathlib,tempfile,textwrap
source=pathlib.Path('/tmp/lpm-next-install-costs/run-timeline-benchmarks.py').read_text()
snippet=textwrap.dedent(source[source.index(" if name.startswith('readiness-'):"):])
with tempfile.TemporaryDirectory() as directory:
 r=pathlib.Path(directory); path=r/'timeline-readiness-scored'; path.mkdir()
 (path/'rows.json').write_text(json.dumps([{'exit_code':0}]))
 for rc in [0,1,2]:
  stopped=None
  try:exec(snippet,dict(name='readiness-scored',rc=rc,r=r,json=json))
  except SystemExit as error:stopped=error.code
  assert stopped==(rc if rc else None),(rc,stopped)
print('readiness nonzero exit codes remain failures even when installs succeed')
