import pathlib,subprocess,time,json,shutil
r=pathlib.Path('/tmp/lpm-next-install-costs');repo='/Users/tolga/.codex/worktrees/install-overhead/rust-client'
steps=[('sharp-prepare',['node',str(r/'run-timeline-sharp-frozen.mjs'),'--prepare']),('sharp-frozen',['node',str(r/'run-timeline-sharp-frozen.mjs')]),('sharp-live-confirmation',['node',str(r/'timeline-live-runner.mjs'),str(r/'timeline-live-sharp-confirmation-config.json')])]
results=[]
for name,cmd in steps:
 assert shutil.disk_usage('/tmp').free>10*1024**3
 print('starting',name,flush=True);start=time.time()
 with (r/('timeline-bench-'+name+'.log')).open('w') as f:rc=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT).returncode
 results.append(dict(name=name,command=cmd,returncode=rc,seconds=time.time()-start));(r/'timeline-sharp-controls-status.json').write_text(json.dumps(results,indent=2));print('finished',name,rc,flush=True)
 if rc:raise SystemExit(rc)
