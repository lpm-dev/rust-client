import json,pathlib,subprocess,time,shutil
root=pathlib.Path('/tmp/lpm-next-install-costs')
status_path=root/'timeline-final-benchmark-status.json'
status=json.loads(status_path.read_text())
assert status[-1]['name']=='readiness-warmup' and status[-1]['returncode']==1
rows=json.loads((root/'timeline-readiness-warmup-final/rows.json').read_text())
assert len(rows)==36 and all(row['exit_code']==0 for row in rows)
assert shutil.disk_usage('/tmp').free>=10*1024**3
cmd=status[-1]['command'].copy()
cmd[cmd.index('--samples')+1]='12'
cmd[cmd.index('--output')+1]=str(root/'timeline-readiness-scored-final')
assert not pathlib.Path(cmd[-1]).exists()
start=time.time()
with (root/'timeline-final-bench-readiness-scored.log').open('w') as log:
 rc=subprocess.run(cmd,cwd='/Users/tolga/.codex/worktrees/install-overhead/rust-client',stdout=log,stderr=subprocess.STDOUT).returncode
status.append(dict(name='readiness-scored',command=cmd,returncode=rc,seconds=time.time()-start,resume_reason='The preserved one-round warmup failed its performance comparison with 36 successful installs. Run the originally planned 12-round cohort to evaluate repetition; no verdict is overridden.'))
status_path.write_text(json.dumps(status,indent=2))
print('finished readiness-scored',rc,flush=True)
raise SystemExit(rc)
