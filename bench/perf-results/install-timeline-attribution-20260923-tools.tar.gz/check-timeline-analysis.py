import pathlib,json,tempfile
ns={};exec(pathlib.Path('/tmp/lpm-next-install-costs/analyze-timelines.py').read_text().split('\nout=[]')[0],ns)
records=[]
for id,start,blocking,duration in [(1,0,0,100),(2,1000,1,300)]:
 records.extend([dict(kind='span_open',id=id,parent=None,name='metadata_parse',fields={'blocking':blocking},at_us=start),dict(kind='event',id=None,parent=id,name='work_start',fields={},at_us=start+10),dict(kind='event',id=None,parent=id,name='work_end',fields={},at_us=start+10+duration),dict(kind='span_close',id=id,parent=None,name='metadata_parse',fields={},at_us=start+20+duration)])
artifact=dict(outcome='success',cutoff_us=2000,open_spans=0,dropped_records=0,records=records)
with tempfile.TemporaryDirectory() as directory:
 p=pathlib.Path(directory)/'timeline.json';p.write_text(json.dumps(artifact));result=ns['analyze'](p)
 assert result['intervals']['blocking_work']['n']==1,result['intervals']['blocking_work']
 assert result['intervals']['blocking_work']['median']==.3
 assert result['intervals']['inline_parse_work']['n']==1
 assert result['intervals']['inline_parse_work']['median']==.1
print('inline metadata parsing is separate from blocking worker execution')
artifact.update(dropped_records=1,open_spans=0)
artifact['records']=[r for r in records if r['kind']!='span_close']
with tempfile.TemporaryDirectory() as directory:
 p=pathlib.Path(directory)/'capped.json';p.write_text(json.dumps(artifact));result=ns['analyze'](p)
 assert result.get('attribution_eligible') is False,result
 assert result['censored_span_count']==2
 assert result['censored_spans'][0]['observed_minimum_ms']==.11
 assert result['censored_spans'][1]['observed_minimum_ms']==.31
 assert result['intervals']=={},'lost records must not produce apparently complete interval summaries'
print('loss invalidates interval attribution even when open_spans is zero')
records=[dict(kind='span_open',id=1,parent=None,name='metadata_request',fields={},at_us=0),dict(kind='span_open',id=2,parent=1,name='metadata_body',fields={},at_us=100)]
for at,name in [(100,'metadata_enqueued'),(200,'metadata_task_start'),(500,'metadata_task_finished'),(600,'resolver_observed'),(800,'graph_commit_start'),(900,'graph_commit_end')]:records.append(dict(kind='event',id=None,parent=1,name=name,fields={},at_us=at))
records.append(dict(kind='event',id=None,parent=2,name='body_end',fields={},at_us=400))
for id,at in [(2,900),(1,1000)]:records.append(dict(kind='span_close',id=id,parent=None,name='closed',fields={},at_us=at))
artifact.update(dropped_records=0,records=sorted(records,key=lambda x:x['at_us']))
with tempfile.TemporaryDirectory() as directory:
 p=pathlib.Path(directory)/'stages.json';p.write_text(json.dumps(artifact));result=ns['analyze'](p)
 for key,expected in [('metadata_dispatch_wait',.1),('metadata_observation_wait',.1),('metadata_ordered_commit_wait',.2),('metadata_commit_wait',.3),('graph_commit_work',.1),('metadata_body_read',.3),('span_metadata_body',.8)]:
  assert result['intervals'][key]['median']==expected,(key,result['intervals'][key])
print('resolver stages and metadata body reading remain separate')
artifact['records']=[dict(kind='span_open',id=1,parent=None,name='tarball_fetch',fields={},at_us=0),dict(kind='span_close',id=1,parent=None,name='tarball_fetch',fields={},at_us=100)]
with tempfile.TemporaryDirectory() as directory:
 p=pathlib.Path(directory)/'unparented.json';p.write_text(json.dumps(artifact));result=ns['analyze'](p)
 assert result['attribution_eligible'] is False,result
 assert result['fetch_ancestry_complete'] is False
 assert result['intervals']=={}
print('unparented fetches invalidate cross-stage attribution')
artifact['records']=[dict(kind='span_open',id=1,parent=None,name='fetch_task',fields={},at_us=0),dict(kind='span_open',id=2,parent=1,name='tarball_fetch',fields={},at_us=10),dict(kind='span_close',id=2,parent=None,name='span_closed',fields={},at_us=90),dict(kind='span_close',id=1,parent=None,name='span_closed',fields={},at_us=100)]
with tempfile.TemporaryDirectory() as directory:
 p=pathlib.Path(directory)/'orphan-ancestor.json';p.write_text(json.dumps(artifact));result=ns['analyze'](p)
 assert result['attribution_eligible'] is False,'a non-root fetch must still reach install_pipeline'
 assert result['fetch_ancestry_complete'] is False
 artifact['records'][0]['name']='install_pipeline'
 p.write_text(json.dumps(artifact));result=ns['analyze'](p)
 assert result['fetch_ancestry_complete'] is True
 assert result['attribution_eligible'] is True
print('fetch ancestry must reach install_pipeline through its entire parent chain')
