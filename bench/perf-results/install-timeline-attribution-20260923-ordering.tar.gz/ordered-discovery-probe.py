import base64,hashlib,http.server,io,json,os,pathlib,subprocess,tarfile,threading,time,urllib.parse
R=pathlib.Path('/tmp/lpm-next-install-costs/ordered-discovery-probe');R.mkdir(exist_ok=False)
names=['timeline-root-a','timeline-root-b','timeline-child-c'];payloads={};events=[];delay_ms=0;start=0
for name in names:
 body=json.dumps(dict(name=name,version='1.0.0',**({'dependencies':{names[2]:'1.0.0'}} if name==names[1] else {}))).encode();buf=io.BytesIO()
 with tarfile.open(fileobj=buf,mode='w:gz') as tar:
  h=tarfile.TarInfo('package/package.json');h.size=len(body);h.mode=0o644;tar.addfile(h,io.BytesIO(body))
 payloads[name]=buf.getvalue()
class Handler(http.server.BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def log_message(self,*args):pass
 def do_GET(self):
  parts=urllib.parse.unquote(urllib.parse.urlparse(self.path).path).strip('/').split('/');name=parts[0]
  if name not in names:self.send_error(404);return
  archive='-' in parts;kind='tarball' if archive else 'metadata'
  events.append(dict(name=name,kind=kind,event='request',ms=(time.monotonic()-start)*1000))
  if not archive and name==names[0]:time.sleep(delay_ms/1000)
  if archive:body=payloads[name];content_type='application/octet-stream'
  else:
   manifest=dict(name=name,version='1.0.0',dist=dict(tarball=base+'/'+name+'/-/'+name+'-1.0.0.tgz',integrity='sha512-'+base64.b64encode(hashlib.sha512(payloads[name]).digest()).decode()))
   if name==names[1]:manifest['dependencies']={names[2]:'1.0.0'}
   value=manifest if len(parts)>1 else dict(name=name,versions={'1.0.0':manifest},**{'dist-tags':{'latest':'1.0.0'}})
   body=json.dumps(value).encode();content_type='application/json'
  self.send_response(200);self.send_header('Content-Type',content_type);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body);self.wfile.flush()
  events.append(dict(name=name,kind=kind,event='response',ms=(time.monotonic()-start)*1000))
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);base='http://127.0.0.1:'+str(server.server_port);threading.Thread(target=server.serve_forever,daemon=True).start();rows=[]
try:
 for sample in range(1,5):
  for delay_ms in ([0,150,300] if sample%2 else [300,150,0]):
   for variant in (['parent','timeline'] if sample%2 else ['timeline','parent']):
    root=R/f'{sample}-{delay_ms}-{variant}';root.mkdir();project=root/'project';project.mkdir();home=root/'home';home.mkdir()
    (project/'package.json').write_text(json.dumps(dict(name='ordered-discovery-probe',version='1.0.0',dependencies={names[0]:'1.0.0',names[1]:'1.0.0'})))
    (project/'.npmrc').write_text('registry='+base+'/\n')
    env={k:os.environ[k] for k in ['PATH','TMPDIR','LANG','SHELL'] if k in os.environ};env.update(HOME=str(home),LPM_HOME=str(root/'lpm-home'),CI='1',LPM_TYPOSQUAT_GUARD='0',RUST_LOG='off')
    if variant=='timeline':env['LPM_INSTALL_TIMELINE_DIR']=str(root/'traces')
    binary='/tmp/lpm-next-install-costs/'+('lpm-known-size' if variant=='parent' else 'lpm-timeline')
    events=[];start=time.monotonic();result=subprocess.run([binary,'--json','--registry',base,'install','--no-frozen-lockfile','--no-skills','--no-editor-setup','--no-security-summary'],cwd=project,env=env,capture_output=True,text=True,timeout=20);wall=(time.monotonic()-start)*1000
    (root/'stdout.json').write_text(result.stdout);(root/'stderr.txt').write_text(result.stderr);assert result.returncode==0,(root,result.stderr,result.stdout)
    response=json.loads(result.stdout);assert response['success'] is True
    ev=list(events)
    def mark(name,event):return next(x['ms'] for x in ev if x['name']==name and x['kind']=='metadata' and x['event']==event)
    row=dict(sample=sample,delay_ms=delay_ms,variant=variant,wall_ms=wall,events=ev,root_a_response_ms=mark(names[0],'response'),root_b_response_ms=mark(names[1],'response'),child_c_request_ms=mark(names[2],'request'),lock_sha256=hashlib.sha256((project/'lpm.lock').read_bytes()).hexdigest())
    rows.append(row);(R/'rows.json').write_text(json.dumps(rows,indent=2));print(sample,delay_ms,variant,round(row['child_c_request_ms']-row['root_b_response_ms'],2),flush=True)
 (R/'plan.json').write_text(json.dumps(dict(registry=base,delays_ms=[0,150,300],rounds=4,binaries={name:hashlib.sha256(pathlib.Path('/tmp/lpm-next-install-costs/'+bin).read_bytes()).hexdigest() for name,bin in [('parent','lpm-known-size'),('timeline','lpm-timeline')]},purpose='Causal diagnostic of child discovery after controlled root metadata delay. Not a production speed comparison.'),indent=2))
finally:server.shutdown();server.server_close()
