# Controlled metadata ordering diagnostic

The fixture has two pinned roots, A and B. Only B depends on pinned child C.
The local registry varies only the delay before sending A metadata: 0, 150, or 300 ms.
Four rounds alternate binary order and delay order. Each install has isolated project, HOME, cache, and store paths.
The parent and timeline binaries complete all 24 installs with identical lockfile bytes.

| Binary | A response delay | Median C request after B response | Samples |
|---|---:|---:|---:|
| parent | 0 ms | 0.43 ms | 4 |
| parent | 150 ms | 160.54 ms | 4 |
| parent | 300 ms | 304.18 ms | 4 |
| timeline | 0 ms | 0.94 ms | 4 |
| timeline | 150 ms | 154.34 ms | 4 |
| timeline | 300 ms | 311.20 ms | 4 |

In all 16 delayed runs, B responds before A, and C is requested only after A responds.
This shows that withholding A metadata postpones discovery of the otherwise-ready B→C branch in this controlled graph.
Source inspection locates the barrier in OrderedMetadataFetches::commit_ready and parked-edge resumption.
The experiment does not establish production savings or justify removing deterministic graph-commit order.
A bounded next candidate is metadata prefetch from completed results while graph mutation remains ordered.
That candidate still needs policy, platform, optional-dependency, error-order, request-budget, graph-parity, and RSS checks.

Raw server timestamps are in rows.json. Every run retains stdout, stderr, lockfile, and installed state.
Timeline variants also retain their diagnostic trace. The sibling ordered-discovery-probe.py contains the exact driver.
This diagnostic ran after the published optimization benchmarks and did not change either binary.
