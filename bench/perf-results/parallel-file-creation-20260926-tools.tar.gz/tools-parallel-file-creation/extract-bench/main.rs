#[global_allocator]
static GLOBAL: mimalloc::MiMalloc = mimalloc::MiMalloc;
use std::time::Instant;
fn main() {
    let args: Vec<String> = std::env::args().collect();
    let (tgz, scratch, reps) = (&args[1], std::path::PathBuf::from(&args[2]), args[3].parse::<usize>().unwrap());
    let mut times = Vec::new();
    for rep in 0..reps {
        let target = scratch.join(format!("x{rep}"));
        let _ = std::fs::remove_dir_all(&target);
        std::fs::create_dir_all(&target).unwrap();
        let started = Instant::now();
        let files = lpm_extractor::extract_tarball_from_reader_pipelined_digests(std::fs::File::open(tgz).unwrap(), &target, || {}).unwrap().len();
        times.push(started.elapsed().as_secs_f64() * 1e3);
        std::fs::remove_dir_all(&target).unwrap();
        assert!(files > 0);
    }
    times.sort_by(f64::total_cmp);
    println!("median {:.0} ms  min {:.0} ms  max {:.0} ms", times[times.len() / 2], times[0], times[times.len() - 1]);
}
