"""Interleaved paired wall-time comparison of two binaries running the same args.

Usage: abcmd.py <rounds> <json-out> <base-binary> <change-binary> <args...>
"""
import json, os, statistics, subprocess, sys, time
rounds, out, base, change, *args = sys.argv[1:]
times = {base: [], change: []}
for i in range(int(rounds)):
    for binary in ((base, change) if i % 2 == 0 else (change, base)):
        start = time.perf_counter()
        subprocess.run([binary, *args], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        times[binary].append((time.perf_counter() - start) * 1000)
b, c = times[base], times[change]
d = [y - x for x, y in zip(b, c)]
print(f"{' '.join(args):16} base {statistics.median(b):6.2f}  change {statistics.median(c):6.2f}  paired {statistics.median(d):+5.2f} ({sum(x < 0 for x in d)}/{len(d)})")
record = {"args": args, "no_update_check": "LPM_NO_UPDATE_CHECK" in os.environ, "base": base, "change": change,
          "base_ms": b, "change_ms": c, "paired_median_ms": statistics.median(d), "change_faster_pairs": sum(x < 0 for x in d), "pairs": len(d)}
existing = json.load(open(out)) if os.path.exists(out) else []
existing.append(record)
json.dump(existing, open(out, "w"), indent=1)
