#include <libproc.h>
#include <sys/proc_info.h>
#include <sys/time.h>
#include <stdio.h>
#include <unistd.h>
int main(void){struct proc_bsdinfo i;struct timeval now;gettimeofday(&now,0);proc_pidinfo(getpid(),PROC_PIDTBSDINFO,0,&i,sizeof i);long us=(now.tv_sec-(long)i.pbi_start_tvsec)*1000000+(now.tv_usec-(long)i.pbi_start_tvusec);printf("%ld\n",us);return 0;}
