#include <pwd.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>
int main(void){char buf[16384];struct passwd e,*r;struct timespec a,b;clock_gettime(CLOCK_MONOTONIC,&a);getpwuid_r(geteuid(),&e,buf,sizeof buf,&r);clock_gettime(CLOCK_MONOTONIC,&b);printf("%ld us\n",(b.tv_sec-a.tv_sec)*1000000+(b.tv_nsec-a.tv_nsec)/1000);return 0;}
