#include <spawn.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <fcntl.h>
extern char **environ;
int main(int argc, char **argv) {
  int n = atoi(argv[1]);
  posix_spawn_file_actions_t fa; posix_spawn_file_actions_init(&fa);
  posix_spawn_file_actions_addopen(&fa, 1, "/dev/null", O_WRONLY, 0);
  for (int i = 0; i < n; i++) {
    pid_t pid; int st;
    if (posix_spawn(&pid, argv[2], &fa, NULL, argv + 2, environ) != 0) { perror("spawn"); return 1; }
    waitpid(pid, &st, 0);
  }
  return 0;
}
