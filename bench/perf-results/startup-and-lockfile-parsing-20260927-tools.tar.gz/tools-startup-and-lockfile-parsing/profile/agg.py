import gzip,json,sys,subprocess,collections
prof=json.load(gzip.open(sys.argv[1])); binary=sys.argv[2]
libs=prof['libs']
lpm_idx=[i for i,l in enumerate(libs) if l['name'].startswith('lpm-rs')]
threads=prof['threads']
addr_needed=set()
def frames_of(th):
    ft=th['frameTable']; fu=th['funcTable']; rt=th['resourceTable']
    return ft,fu,rt
for th in threads:
    ft,fu,rt=frames_of(th)
    for fi in range(ft['length']):
        func=ft['func'][fi]; res=fu['resource'][func]
        if res is not None and res>=0 and rt['lib'][res] in lpm_idx:
            addr_needed.add(ft['address'][fi])
addrs=sorted(a for a in addr_needed if a is not None and a>=0)
names={}
for i in range(0,len(addrs),2000):
    chunk=addrs[i:i+2000]
    out=subprocess.run(['atos','-o',binary,'-arch','arm64','-l','0x100000000']+[hex(0x100000000+a) for a in chunk],capture_output=True,text=True).stdout.splitlines()
    for a,n in zip(chunk,out):
        n=n.split(' (in ')[0]
        names[a]=n
def short(n):
    # strip generics/hash
    import re
    n=re.sub(r'::h[0-9a-f]{16}$','',n)
    return n[:140]
incl=collections.Counter(); selfc=collections.Counter(); total=0
for th in threads:
    ft,fu,rt=frames_of(th)
    st=th['stackTable']; samples=th['samples']
    stacks=samples['stack']
    strings=th.get('stringArray') or prof.get('shared',{}).get('stringArray')
    def fname(fi):
        func=ft['func'][fi]; res=fu['resource'][func]
        if res is not None and res>=0 and rt['lib'][res] in lpm_idx:
            return short(names.get(ft['address'][fi],hex(ft['address'][fi])))
        lib=libs[rt['lib'][res]]['name'] if res is not None and res>=0 else '?'
        return '['+lib+']'
    cache={}
    for s in stacks:
        if s is None: continue
        total+=1
        seen=set(); first=True; x=s
        while x is not None:
            fi=st['frame'][x]
            n=fname(fi)
            if first: selfc[n]+=1; first=False
            if n not in seen: incl[n]+=1; seen.add(n)
            x=st['prefix'][x]
print('total samples',total)
print('--- inclusive top 60')
for n,c in incl.most_common(60): print(f'{c/total*100:6.2f}%  {n}')
print('--- self top 30')
for n,c in selfc.most_common(30): print(f'{c/total*100:6.2f}%  {n}')
