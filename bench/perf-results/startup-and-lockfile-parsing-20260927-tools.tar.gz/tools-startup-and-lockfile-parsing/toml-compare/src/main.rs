use std::time::Instant;
fn bench<T>(name: &str, n: usize, mut f: impl FnMut() -> T) {
    let mut v = Vec::with_capacity(n);
    for _ in 0..n { let t = Instant::now(); std::hint::black_box(f()); v.push(t.elapsed().as_secs_f64() * 1e3); }
    v.sort_by(f64::total_cmp);
    println!("  {name:44} median {:.3} ms", v[n / 2]);
}
fn main() {
    let mut differ = 0;
    for path in std::env::args().skip(1) {
        let raw = std::fs::read_to_string(&path).unwrap();
        let lockfile = lpm_lockfile::Lockfile::from_toml(&raw).unwrap();
        let a = toml08::to_string_pretty(&lockfile).unwrap();
        let b = toml1::to_string_pretty(&lockfile).unwrap();
        let same_as_disk = a == raw;
        println!("{path}: {} bytes, 0.8 writer reproduces file: {same_as_disk}, toml 1 writer identical to 0.8: {}", raw.len(), a == b);
        if a != b {
            differ += 1;
            let (la, lb): (Vec<_>, Vec<_>) = (a.lines().collect(), b.lines().collect());
            for (i, (x, y)) in la.iter().zip(lb.iter()).enumerate() { if x != y { println!("  first diff line {i}:\n    0.8: {x}\n    0.9: {y}"); break; } }
            println!("  lines 0.8={} 0.9={}", la.len(), lb.len());
        }
        let back: lpm_lockfile::Lockfile = toml1::from_str(&raw).unwrap();
        println!("  toml 1 parse round-trips to same model: {}", toml08::to_string_pretty(&back).unwrap() == a);
        bench("toml 0.8 from_str::<Lockfile>", 100, || toml08::from_str::<lpm_lockfile::Lockfile>(&raw).unwrap());
        bench("toml 1 from_str::<Lockfile>", 100, || toml1::from_str::<lpm_lockfile::Lockfile>(&raw).unwrap());
    }
    println!("files with differing output: {differ}");
}
