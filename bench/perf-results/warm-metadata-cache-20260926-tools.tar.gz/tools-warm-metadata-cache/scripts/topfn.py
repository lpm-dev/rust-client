import sys,gzip,json,bisect,re,collections
prof,syms,procname,nproc=sys.argv[1],sys.argv[2],sys.argv[3],int(sys.argv[4]); focus=sys.argv[5] if len(sys.argv)>5 else None
p=json.load(gzip.open(prof)); s=json.load(open(syms))
strings=s["string_table"]; tables={}
for lib in s["data"]:
    st=sorted(lib["symbol_table"],key=lambda e:e["rva"]); tables[lib["debug_name"]]=([e["rva"] for e in st],st)
def sym(lib,a):
    t=tables.get(lib)
    if t:
        r,st=t;i=bisect.bisect_right(r,a)-1
        if i>=0 and a<st[i]["rva"]+max(st[i]["size"],1): return re.sub(r"::h[0-9a-f]{16}$","",strings[st[i]["symbol"]])
    return f"{lib}+{a:x}"
iv=p["meta"]["interval"]; incl=collections.Counter(); selfc=collections.Counter(); th=collections.Counter()
for t in p["threads"]:
    if t["processName"]!=procname: continue
    ft,fn,rt,stk,sm=t["frameTable"],t["funcTable"],t["resourceTable"],t["stackTable"],t["samples"]
    names=[sym(p["libs"][rt["lib"][fn["resource"][ft["func"][i]]]]["debugName"],ft["address"][i]) for i in range(ft["length"])]
    memo={}
    cpu=sm.get("threadCPUDelta")
    for k in range(sm["length"]):
        si=sm["stack"][k]
        if si is None: continue
        if si not in memo:
            out=[];c=si
            while c is not None: out.append(names[stk["frame"][c]]); c=stk["prefix"][c]
            memo[si]=out
        fr=memo[si]
        if focus and not any(focus in x for x in fr): continue
        if any(w in fr[0] for w in ("semaphore_wait","__psynch_cvwait","kevent","__ulock_wait","mach_msg2_trap","__semwait","__workq_kernreturn")): continue
        th[re.sub(r"-?\d+$","",t["name"])]+=1; selfc[fr[0]]+=1
        for x in set(fr): incl[x]+=1
print("busy ms/run by thread:", {k:round(v*iv/nproc,1) for k,v in th.most_common(8)})
print("-- inclusive")
for k,v in incl.most_common(45): print(f"{v*iv/nproc:7.2f}  {k[:150]}")
print("-- self")
for k,v in selfc.most_common(20): print(f"{v*iv/nproc:7.2f}  {k[:150]}")
