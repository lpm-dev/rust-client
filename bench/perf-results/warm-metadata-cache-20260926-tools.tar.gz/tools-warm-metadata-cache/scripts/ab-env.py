import json, os, shutil, subprocess, sys, time, statistics
work = sys.argv[1]; binary = sys.argv[2]; blocks = int(sys.argv[3]); rounds = int(sys.argv[4])
variants = {"default": {}, "fanout256": {"LPM_NPM_FANOUT": "256"}}
base_env = dict(os.environ, HOME=f"{work}/home", CI="1", NO_COLOR="1", LPM_HOME=f"{work}/lpm-home", LPM_STORE_VERSION="v2")
proj = f"{work}/project"
def reset():
    for name in ("node_modules", ".lpm"):
        shutil.rmtree(f"{proj}/{name}", ignore_errors=True)
    for name in ("lpm.lock", "lpm.lockb"):
        try: os.remove(f"{proj}/{name}")
        except FileNotFoundError: pass
def run(extra):
    reset()
    start = time.perf_counter()
    out = subprocess.run([binary, "--json", "install", "--timing", "--no-security-summary", "--no-skills", "--no-editor-setup"], cwd=proj, env=dict(base_env, **extra), capture_output=True, check=True).stdout
    wall = (time.perf_counter() - start) * 1e3
    t = json.loads(out)["timing"]
    return wall, t["resolve_ms"], t["total_ms"]
rows = {k: [] for k in variants}
for block in range(blocks):
    run({}); run({})
    for r in range(rounds):
        order = list(variants) if r % 2 == 0 else list(reversed(variants))
        for k in order:
            rows[k].append(run(variants[k]))
for k, v in rows.items():
    print(k, "n", len(v), "wall", round(statistics.median(x[0] for x in v), 1), "resolve", statistics.median(x[1] for x in v), "total", statistics.median(x[2] for x in v))
names = list(variants)
pairs = [(b[1]-a[1], b[2]-a[2]) for a, b in zip(rows[names[0]], rows[names[1]])]
print("paired", names[1], "-", names[0], "resolve", statistics.median(p[0] for p in pairs), "total", statistics.median(p[1] for p in pairs), "faster in", sum(p[1] < 0 for p in pairs), "/", len(pairs))
