import json, os, shutil, subprocess, sys, time
work, binary = sys.argv[1], sys.argv[2]
extra = dict(x.split("=",1) for x in sys.argv[3:])
env0 = dict(os.environ, HOME=f"{work}/home", CI="1", NO_COLOR="1", LPM_HOME=f"{work}/lpm-home", LPM_STORE_VERSION="v2", LPM_TIMING_DETAIL="trace", **extra)
proj = f"{work}/project"
shutil.rmtree(f"{work}/lpm-home/cache", ignore_errors=True)
shutil.copytree(f"{work}/cache-snapshot", f"{work}/lpm-home/cache")
expiry = time.time() + 250
meta = f"{work}/lpm-home/cache/metadata"
for name in os.listdir(meta):
    os.utime(os.path.join(meta, name), (expiry, expiry))
for name in ("node_modules", ".lpm"): shutil.rmtree(f"{proj}/{name}", ignore_errors=True)
for name in ("lpm.lock", "lpm.lockb"):
    try: os.remove(f"{proj}/{name}")
    except FileNotFoundError: pass
t = json.loads(subprocess.run([binary, "--json", "install", "--timing", "--no-security-summary", "--no-skills", "--no-editor-setup"], cwd=proj, env=env0, capture_output=True).stdout)["timing"]
mf = t["detail"]["resolve"]["metadata_fetch"]; sch = t["detail"]["resolve"]["scheduler"]["metadata_dispatcher"]
print(extra, "resolve", t["resolve_ms"], "calls", mf["calls"], "hits", mf["cache_hit_count"], "proj", mf["projection_hit_count"], "304", mf["not_modified_count"], "semwait", round(sch["semaphore_wait_ms"],1), sch["semaphore_wait_count"], "inflight_hw", sch["inflight_high_water"], "pending_hw", sch["pending_high_water"])
