import sys,gzip,json,bisect,re,collections
prof,syms,procname=sys.argv[1],sys.argv[2],sys.argv[3]
p=json.load(gzip.open(prof)); s=json.load(open(syms))
strings=s["string_table"]; tables={}
for lib in s["data"]:
    st=sorted(lib["symbol_table"],key=lambda e:e["rva"]); tables[lib["debug_name"]]=([e["rva"] for e in st],st)
def sym(lib,a):
    t=tables.get(lib)
    if t:
        r,st=t;i=bisect.bisect_right(r,a)-1
        if i>=0 and a<st[i]["rva"]+max(st[i]["size"],1): return re.sub(r"::h[0-9a-f]{16}$","",strings[st[i]["symbol"]])
    return f"{lib}+{a:x}"
leaf=collections.Counter(); leaf2=collections.Counter()
for t in p["threads"]:
    if t["processName"]!=procname: continue
    ft,fn,rt,stk,sm=t["frameTable"],t["funcTable"],t["resourceTable"],t["stackTable"],t["samples"]
    names=[sym(p["libs"][rt["lib"][fn["resource"][ft["func"][i]]]]["debugName"],ft["address"][i]) for i in range(ft["length"])]
    memo={}
    for k in range(sm["length"]):
        si=sm["stack"][k]
        if si is None: continue
        if si not in memo:
            out=[];c=si
            while c is not None: out.append(names[stk["frame"][c]]); c=stk["prefix"][c]
            memo[si]=out
        fr=memo[si]
        leaf[fr[0]]+=1
        # leaf + first rust frame
        rust=next((x for x in fr if "::" in x and not x.startswith("std::sys")),"")
        leaf2[(fr[0],rust[:110])]+=1
for k,v in leaf.most_common(25): print(v,k[:120])
print("----")
for k,v in leaf2.most_common(40): print(v,k)
