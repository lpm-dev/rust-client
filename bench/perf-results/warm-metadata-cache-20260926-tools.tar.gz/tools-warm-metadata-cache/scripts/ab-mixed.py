import json, os, shutil, subprocess, sys, time, statistics
work, binary, rounds = sys.argv[1], sys.argv[2], int(sys.argv[3])
variants = {"f16": {}, "f256": {"LPM_NPM_FANOUT": "256"}}
env0 = dict(os.environ, HOME=f"{work}/home", CI="1", NO_COLOR="1", LPM_HOME=f"{work}/lpm-home", LPM_STORE_VERSION="v2")
proj = f"{work}/project"
def restore():
    shutil.rmtree(f"{work}/lpm-home/cache", ignore_errors=True)
    shutil.copytree(f"{work}/cache-snapshot", f"{work}/lpm-home/cache")
    expiry = time.time() + 250
    meta = f"{work}/lpm-home/cache/metadata"
    for name in os.listdir(meta):
        path = os.path.join(meta, name)
        if os.path.isfile(path):
            os.utime(path, (expiry, expiry))
    for name in ("node_modules", ".lpm"):
        shutil.rmtree(f"{proj}/{name}", ignore_errors=True)
    for name in ("lpm.lock", "lpm.lockb"):
        try: os.remove(f"{proj}/{name}")
        except FileNotFoundError: pass
def run(extra):
    restore()
    out = subprocess.run([binary, "--json", "install", "--timing", "--no-security-summary", "--no-skills", "--no-editor-setup"], cwd=proj, env=dict(env0, **extra), capture_output=True).stdout
    t = json.loads(out)["timing"]
    return t["resolve_ms"], t["total_ms"]
run({})
rows = {k: [] for k in variants}
for r in range(rounds):
    order = list(variants) if r % 2 == 0 else list(reversed(variants))
    for k in order:
        rows[k].append(run(variants[k]))
for k, v in rows.items():
    print(k, "resolve", sorted(x[0] for x in v), "median", statistics.median(x[0] for x in v))
pairs = [b[0]-a[0] for a, b in zip(rows["f16"], rows["f256"])]
print("paired f256-f16 resolve median", statistics.median(pairs), "faster", sum(p < 0 for p in pairs), "/", len(pairs))
