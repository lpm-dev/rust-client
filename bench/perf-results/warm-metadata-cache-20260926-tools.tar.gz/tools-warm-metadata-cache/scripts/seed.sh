#!/bin/bash
# Usage: seed.sh <work-dir> <lpm-binary>
# Resolves the project once so the metadata cache is fresh for the next runs.
set -euo pipefail
work=$1; binary=$2
rm -rf "$work/project/node_modules" "$work/project/.lpm" "$work/project/lpm.lock" "$work/project/lpm.lockb"
"$(dirname "$0")/lpm-env.sh" "$work" "$binary" --json install --no-security-summary --no-skills --no-editor-setup >/dev/null
