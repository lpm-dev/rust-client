#!/bin/bash
S=$1; W=$2; B=$3; N=$4
for i in $(seq 1 $N); do
rm -rf $W/project/node_modules $W/project/.lpm $W/project/lpm.lock $W/project/lpm.lockb
LPM_TIMING_DETAIL=trace $S/lpm-env.sh $W $B --json install --timing --no-security-summary --no-skills --no-editor-setup > $S/loop.json 2>/dev/null
python3 -c "
import json
d=json.load(open('$S/loop.json'))
t=d['timing']; mf=t['detail']['resolve']['metadata_fetch']; a=mf['attribution']
sch=t['detail']['resolve']['scheduler']['metadata_dispatcher']
print(t['resolve_ms'], t['total_ms'], 'read',a['cache_read_sum_ms'],'max',a['raw_fetch_max_ms'],'semwait',round(sch['semaphore_wait_ms'],1),sch['semaphore_wait_count'],'proj',mf.get('projection_hit_count'))
"
done
