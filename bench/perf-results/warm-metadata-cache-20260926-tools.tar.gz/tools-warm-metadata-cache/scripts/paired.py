import json, sys, statistics, math
def p95(v):
    v=sorted(v); return v[max(0, math.ceil(0.95*len(v))-1)]
for path in sys.argv[1:]:
    rows=[r for r in json.load(open(path)) if r["manager"]=="lpm"]
    assert all(r["ok"] for r in rows), path
    for state in sorted({r["scenario"] for r in rows}):
        by={}
        for r in rows:
            if r["scenario"]==state: by.setdefault(r["variant"],{})[r["sample"]]=r["wall_ms"]
        base,change=by["base-893"],by["change"]
        samples=sorted(set(base)&set(change))
        diffs=[change[s]-base[s] for s in samples]
        print(f"{path.split('/research/')[-1]:40s} {state:28s} n={len(samples)} base {statistics.median(base.values()):7.1f}/{p95(base.values()):7.1f}  change {statistics.median(change.values()):7.1f}/{p95(change.values()):7.1f}  paired {statistics.median(diffs):+6.1f} ({sum(d<0 for d in diffs)}/{len(diffs)})")
