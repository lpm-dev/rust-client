import json, os, shutil, subprocess, sys, time, statistics
work = sys.argv[1]; bins = {"base": sys.argv[2], "new": sys.argv[3]}; blocks = int(sys.argv[4]); rounds = int(sys.argv[5])
env = dict(os.environ, HOME=f"{work}/home", CI="1", NO_COLOR="1", LPM_HOME=f"{work}/lpm-home", LPM_STORE_VERSION="v2")
proj = f"{work}/project"
def reset():
    for name in ("node_modules", ".lpm"):
        shutil.rmtree(f"{proj}/{name}", ignore_errors=True)
    for name in ("lpm.lock", "lpm.lockb"):
        try: os.remove(f"{proj}/{name}")
        except FileNotFoundError: pass
def run(binary, timing=True):
    reset()
    start = time.perf_counter()
    out = subprocess.run([binary, "--json", "install", "--timing", "--no-security-summary", "--no-skills", "--no-editor-setup"], cwd=proj, env=env, capture_output=True, check=True).stdout
    wall = (time.perf_counter() - start) * 1e3
    t = json.loads(out)["timing"]
    return wall, t["resolve_ms"], t["total_ms"]
rows = {k: [] for k in bins}
for block in range(blocks):
    for binary in bins.values():
        run(binary); run(binary)
    for r in range(rounds):
        order = list(bins) if r % 2 == 0 else list(reversed(bins))
        for k in order:
            rows[k].append(run(bins[k]))
for k, v in rows.items():
    print(k, "n", len(v), "wall", round(statistics.median(x[0] for x in v), 1), "resolve", statistics.median(x[1] for x in v), "total", statistics.median(x[2] for x in v))
pairs = [(b[0]-a[0], b[1]-a[1], b[2]-a[2]) for a, b in zip(rows["base"], rows["new"])]
print("paired new-base: wall", round(statistics.median(p[0] for p in pairs),1), "resolve", statistics.median(p[1] for p in pairs), "total", statistics.median(p[2] for p in pairs), "new faster in", sum(p[2] < 0 for p in pairs), "/", len(pairs))
