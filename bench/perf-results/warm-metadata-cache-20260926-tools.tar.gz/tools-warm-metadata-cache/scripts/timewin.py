import sys,gzip,json,bisect,re,collections
prof,syms,procname,run_index=sys.argv[1],sys.argv[2],sys.argv[3],int(sys.argv[4])
p=json.load(gzip.open(prof)); s=json.load(open(syms))
strings=s["string_table"]; tables={}
for lib in s["data"]:
    st=sorted(lib["symbol_table"],key=lambda e:e["rva"]); tables[lib["debug_name"]]=([e["rva"] for e in st],st)
def sym(lib,a):
    t=tables.get(lib)
    if t:
        r,st=t;i=bisect.bisect_right(r,a)-1
        if i>=0 and a<st[i]["rva"]+max(st[i]["size"],1): return re.sub(r"::h[0-9a-f]{16}$","",strings[st[i]["symbol"]])
    return f"{lib}+{a:x}"
pids=[]
for t in p["threads"]:
    if t["processName"]==procname and t["pid"] not in pids: pids.append(t["pid"])
pid=pids[run_index]
IDLE=("__psynch_cvwait","kevent","__ulock_wait","semaphore_wait_trap","mach_msg2_trap","swtch_pri","__workq_kernreturn")
events=[]
t0=None
for t in p["threads"]:
    if t["pid"]!=pid: continue
    ft,fn,rt,stk,sm=t["frameTable"],t["funcTable"],t["resourceTable"],t["stackTable"],t["samples"]
    names=[sym(p["libs"][rt["lib"][fn["resource"][ft["func"][i]]]]["debugName"],ft["address"][i]) for i in range(ft["length"])]
    times=sm.get("time") or []
    if not times and "timeDeltas" in sm:
        acc=0; times=[]
        for d in sm["timeDeltas"]: acc+=d; times.append(acc)
    for k in range(sm["length"]):
        si=sm["stack"][k]
        if si is None: continue
        out=[];c=si
        while c is not None: out.append(names[stk["frame"][c]]); c=stk["prefix"][c]
        rust=[x for x in out if "::" in x and not x.startswith(("std::","core::","tokio::","alloc::","<alloc","<core","<std"))]
        events.append((times[k], t["name"], out[0], rust[0][:90] if rust else "", out))
events.sort()
start=events[0][0]
buckets=collections.defaultdict(collections.Counter)
for tm,th,lf,r,_ in events:
    b=int((tm-start))
    key=("IDLE" if lf in IDLE else lf[:30])+" | "+r[:70]
    buckets[b][key]+=1
for b in sorted(buckets):
    busy=[(k,v) for k,v in buckets[b].most_common() if not k.startswith("IDLE")]
    idle=sum(v for k,v in buckets[b].items() if k.startswith("IDLE"))
    print(b, "idle", idle, busy[:4])
