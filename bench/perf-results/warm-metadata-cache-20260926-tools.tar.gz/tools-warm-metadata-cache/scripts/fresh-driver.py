import os, shutil, subprocess, sys
work, n, binary = sys.argv[1], int(sys.argv[2]), sys.argv[3]
env = dict(os.environ, HOME=f"{work}/home", CI="1", NO_COLOR="1", LPM_HOME=f"{work}/lpm-home", LPM_STORE_VERSION="v2")
for _ in range(n):
    for name in ("node_modules", ".lpm"):
        shutil.rmtree(f"{work}/project/{name}", ignore_errors=True)
    try: os.remove(f"{work}/project/lpm.lock")
    except FileNotFoundError: pass
    subprocess.run([binary, "--json", "install", "--no-security-summary", "--no-skills", "--no-editor-setup"], cwd=f"{work}/project", env=env, stdout=subprocess.DEVNULL, check=True)
