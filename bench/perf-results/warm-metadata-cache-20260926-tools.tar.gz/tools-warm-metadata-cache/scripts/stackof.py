import sys,gzip,json,bisect,re,collections
prof,syms,procname,needle=sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4]
p=json.load(gzip.open(prof)); s=json.load(open(syms))
strings=s["string_table"]; tables={}
for lib in s["data"]:
    st=sorted(lib["symbol_table"],key=lambda e:e["rva"]); tables[lib["debug_name"]]=([e["rva"] for e in st],st)
def sym(lib,a):
    t=tables.get(lib)
    if t:
        r,st=t;i=bisect.bisect_right(r,a)-1
        if i>=0 and a<st[i]["rva"]+max(st[i]["size"],1): return re.sub(r"::h[0-9a-f]{16}$","",strings[st[i]["symbol"]])
    return f"{lib}+{a:x}"
stacks=collections.Counter()
for t in p["threads"]:
    if t["processName"]!=procname: continue
    ft,fn,rt,stk,sm=t["frameTable"],t["funcTable"],t["resourceTable"],t["stackTable"],t["samples"]
    names=[sym(p["libs"][rt["lib"][fn["resource"][ft["func"][i]]]]["debugName"],ft["address"][i]) for i in range(ft["length"])]
    for k in range(sm["length"]):
        si=sm["stack"][k]
        if si is None: continue
        out=[];c=si
        while c is not None: out.append(names[stk["frame"][c]]); c=stk["prefix"][c]
        if any(needle in x for x in out):
            key=(t["name"],)+tuple(x[:120] for x in out if not x.startswith(("core::","std::","<core","<std","tokio::runtime::task","alloc::")))[:28]
            stacks[key]+=1
for k,v in stacks.most_common(3):
    print(v); [print("   ",x) for x in k]
