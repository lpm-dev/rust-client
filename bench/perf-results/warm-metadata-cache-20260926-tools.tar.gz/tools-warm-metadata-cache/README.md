# Warm metadata cache measurement tools

- `harness/`: frozen-registry drivers (copies of each fixture's `run.mjs` with this change's variants and states). They expect the research layout with `runner.mjs`, `replay-proxy.mjs`, `tls.mjs` and the frozen captures next to them.
- `rows/`: raw harness rows. `scripts/paired.py rows/*.json` reproduces the tables.
- `scripts/lpm-env.sh <work> <binary> args...`: runs LPM with an isolated `HOME`/`LPM_HOME` under `<work>`; `<work>/project` holds the fixture `package.json`.
- `scripts/ab-fresh.py`: paired fresh-checkout runs of two binaries with the cache inside its freshness window.
- `scripts/ab-env.py`: paired runs of one binary with and without `LPM_NPM_FANOUT=256`.
- `scripts/ab-mixed.py`, `scripts/mixed-trace.py`: warm cache plus uncached dependencies against the live registry, with and without the wider fanout.
- `scripts/ab-stale.py`: restores a seeded cache, expires every entry and runs paired installs against the live registry; a trailing argument prints traced revalidation and body-byte counts.
- `scripts/trace-loop.sh`: repeated traced installs printing summed cache-read time, semaphore waits and projection hits.
- `scripts/topfn.py`, `timewin.py`, `leafwin.py`, `stackof.py`: samply profile analysis (per-function time, per-millisecond thread activity, blocked-thread leaves, call stacks of a frame).
- `spawn-stall-probe/`: spawns `node --version` while eight threads allocate and read files, and reports their worst gaps.
