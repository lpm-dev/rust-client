use std::os::unix::process::CommandExt;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

fn main() {
    let program = std::env::args().nth(1).expect("program");
    let group = std::env::args().nth(2).as_deref() == Some("group");
    let stop = Arc::new(AtomicBool::new(false));
    let gaps = Arc::new(Mutex::new(Vec::new()));
    let mut workers = Vec::new();
    for index in 0..8 {
        let stop = Arc::clone(&stop);
        let gaps = Arc::clone(&gaps);
        workers.push(std::thread::spawn(move || {
            let mut last = Instant::now();
            let mut worst = Duration::ZERO;
            let path = std::env::temp_dir().join(format!("spawnstall-{index}"));
            std::fs::write(&path, b"x").unwrap();
            while !stop.load(Ordering::Relaxed) {
                let buffer = vec![index as u8; 256 * 1024];
                std::hint::black_box(&buffer);
                drop(std::fs::read(&path).unwrap());
                let now = Instant::now();
                worst = worst.max(now - last);
                last = now;
            }
            gaps.lock().unwrap().push(worst);
        }));
    }
    std::thread::sleep(Duration::from_millis(50));
    let mut spawn_times = Vec::new();
    for _ in 0..20 {
        let start = Instant::now();
        let mut command = std::process::Command::new(&program);
        command.arg("--version").stdout(std::process::Stdio::null());
        if group {
            command.process_group(0);
        }
        let mut child = command.spawn().unwrap();
        let spawned = start.elapsed();
        child.wait().unwrap();
        spawn_times.push((spawned, start.elapsed()));
        std::thread::sleep(Duration::from_millis(5));
    }
    stop.store(true, Ordering::Relaxed);
    for worker in workers {
        worker.join().unwrap();
    }
    let mut gaps = gaps.lock().unwrap().clone();
    gaps.sort();
    let spawn: Vec<_> = spawn_times.iter().map(|(s, _)| s.as_secs_f64() * 1e3).collect();
    let total: Vec<_> = spawn_times.iter().map(|(_, t)| t.as_secs_f64() * 1e3).collect();
    println!(
        "{program} group={group}: worker max gaps ms {:?}; spawn() ms median {:.2} max {:.2}; spawn+wait median {:.2}",
        gaps.iter().map(|g| (g.as_secs_f64() * 1e3 * 10.0).round() / 10.0).collect::<Vec<_>>(),
        median(spawn.clone()), spawn.iter().cloned().fold(0.0, f64::max), median(total)
    );
}

fn median(mut values: Vec<f64>) -> f64 {
    values.sort_by(f64::total_cmp);
    values[values.len() / 2]
}
