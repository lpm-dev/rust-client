import ast, json, re, statistics, sys
S = sys.argv[1]
def parse(path):
    rows = {"base": [], "change": []}
    for line in open(path):
        m = re.match(r"^(base|change) (\(.*\))$", line.strip())
        if m:
            wall, resolve, total, extra = ast.literal_eval(m.group(2))
            fields = dict(item.split("=", 1) for item in extra.split()) if extra else {}
            rows[m.group(1)].append({"wall_ms": round(wall, 1), "resolve_ms": resolve, "total_ms": total, **fields})
    return rows
def nearest_rank(values, q):
    ordered = sorted(values)
    return ordered[max(0, -(-len(ordered) * q // 100) - 1)]
def summarize(rows):
    out = {}
    for arm, runs in rows.items():
        totals = [r["total_ms"] for r in runs]; resolves = [r["resolve_ms"] for r in runs]
        out[arm] = {"runs": len(runs), "total_median_ms": statistics.median(totals), "total_p95_ms": nearest_rank(totals, 95),
                    "resolve_median_ms": statistics.median(resolves), "resolve_p95_ms": nearest_rank(resolves, 95)}
    pairs = [(c["total_ms"] - b["total_ms"], c["resolve_ms"] - b["resolve_ms"]) for b, c in zip(rows["base"], rows["change"])]
    out["paired"] = {"total_median_ms": statistics.median(p[0] for p in pairs), "resolve_median_ms": statistics.median(p[1] for p in pairs),
                     "change_faster": sum(p[0] < 0 for p in pairs), "pairs": len(pairs)}
    return out
def summary_lines(path):
    out = {}
    for line in open(path):
        m = re.match(r"^(base|change) wall \S+ resolve (\S+) total (\S+) (\[.*\])$", line.strip())
        if m:
            resolves = ast.literal_eval(m.group(4))
            out[m.group(1)] = {"runs": len(resolves), "resolve_median_ms": float(m.group(2)), "total_median_ms": float(m.group(3)), "resolve_ms_sorted": resolves}
        m = re.match(r"^paired change-base resolve (\S+) total (\S+) faster (\d+) / (\d+)$", line.strip())
        if m:
            out["paired"] = {"resolve_median_ms": float(m.group(1)), "total_median_ms": float(m.group(2)), "change_faster": int(m.group(3)), "pairs": int(m.group(4))}
    return out
seed = json.load(open(f"{S}/t3o-seed2.json"))["timing"]
exact = seed["detail"]["resolve"]["metadata_fetch"]["npm_direct_version_documents"]
summary = {
    "base": "c398505e1 (#894, release build)",
    "machine": "Apple Silicon, 18 cores; live registry.npmjs.org",
    "seed_first_install": {"oversized_history_count": exact["oversized_history_count"], "exact_document_body_bytes": exact["body_bytes_sum"], "total_ms": seed["total_ms"]},
    "expired_cache": {**summarize(parse(f"{S}/t3o-stale-ab2.txt")), "raw": parse(f"{S}/t3o-stale-ab2.txt")},
    "expired_cache_registry_changed_mid_run": {**summarize(parse(f"{S}/t3o-stale-ab1.txt")), "raw": parse(f"{S}/t3o-stale-ab1.txt")},
    "cold_metadata_round_1": summarize(parse(f"{S}/t3o-cold-ab.txt")),
    "cold_metadata_round_2": summary_lines(f"{S}/t3o-cold-ab2.txt"),
}
json.dump(summary, open(sys.argv[2], "w"), indent=2)
for key in ("expired_cache", "expired_cache_registry_changed_mid_run", "cold_metadata_round_1", "cold_metadata_round_2"):
    s = summary[key]; print(key, {k: v for k, v in s.items() if k != "raw"})
