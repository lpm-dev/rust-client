#!/bin/bash
W=$1; shift
cd $W/project && exec env HOME=$W/home CI=1 NO_COLOR=1 LPM_HOME=$W/lpm-home LPM_STORE_VERSION=v2 "$@"
