import json, os, shutil, subprocess, sys, time, statistics
work, snapshot = sys.argv[1], sys.argv[2]; bins = {"base": sys.argv[3], "change": sys.argv[4]}; rounds = int(sys.argv[5]); trace = len(sys.argv) > 6
env = dict(os.environ, HOME=f"{work}/home", CI="1", NO_COLOR="1", LPM_HOME=f"{work}/lpm-home", LPM_STORE_VERSION="v2")
if trace: env["LPM_TIMING_DETAIL"] = "trace"
proj = f"{work}/project"
def restore():
    shutil.rmtree(f"{work}/lpm-home/cache", ignore_errors=True)
    shutil.copytree(snapshot, f"{work}/lpm-home/cache")
    expired = time.time() - 5
    meta = f"{work}/lpm-home/cache/metadata"
    for name in os.listdir(meta):
        os.utime(os.path.join(meta, name), (expired, expired))
    for name in ("node_modules", ".lpm"): shutil.rmtree(f"{proj}/{name}", ignore_errors=True)
    for name in ("lpm.lock", "lpm.lockb"):
        try: os.remove(f"{proj}/{name}")
        except FileNotFoundError: pass
def run(binary):
    restore()
    start = time.perf_counter()
    out = subprocess.run([binary, "--json", "install", "--timing", "--no-security-summary", "--no-skills", "--no-editor-setup"], cwd=proj, env=env, capture_output=True).stdout
    wall = (time.perf_counter() - start) * 1e3
    t = json.loads(out)["timing"]
    extra = ""
    if trace:
        mf = t["detail"]["resolve"]["metadata_fetch"]
        ex = mf.get("npm_direct_version_documents", {})
        extra = f"304={mf['not_modified_count']} body={mf['body_bytes_sum']} proj={mf.get('projection_hit_count')} exact_body={ex.get('body_bytes_sum')} oversized={ex.get('oversized_history_count')} skipped={ex.get('oversized_history_skip_count')}"
    return wall, t["resolve_ms"], t["total_ms"], extra
rows = {k: [] for k in bins}
for r in range(rounds):
    order = list(bins) if r % 2 == 0 else list(reversed(bins))
    for k in order:
        rows[k].append(run(bins[k]))
        if trace: print(k, rows[k][-1])
for k, v in rows.items():
    print(k, "wall", round(statistics.median(x[0] for x in v), 1), "resolve", statistics.median(x[1] for x in v), "total", statistics.median(x[2] for x in v), sorted(x[1] for x in v))
pairs = [(b[1]-a[1], b[2]-a[2]) for a, b in zip(rows["base"], rows["change"])]
print("paired change-base resolve", statistics.median(p[0] for p in pairs), "total", statistics.median(p[1] for p in pairs), "faster", sum(p[1] < 0 for p in pairs), "/", len(pairs))
