"""Median per-step tail durations (ms) from LPM_TAIL_MARK lines, per variant.

Usage: tail2.py <research-dir> <fixture> <stage> <state>
"""
import glob, os, statistics, sys

research, fixture, stage, state = sys.argv[1:5]
by_variant = {}
for path in sorted(glob.glob(f"{research}/{fixture}/{stage}/artifacts/{state}/*/*/stderr.log")):
    variant = path.split(os.sep)[-3]
    marks = []
    for line in open(path, errors="replace"):
        at = line.find("LPM_TAIL_MARK ")
        if at >= 0:
            label, micros = line[at + len("LPM_TAIL_MARK "):].split()
            marks.append((label, int(micros)))
    if len(marks) < 2:
        continue
    steps = by_variant.setdefault(variant, {})
    for (_, before), (label, after) in zip(marks, marks[1:]):
        steps.setdefault(label, []).append((after - before) / 1000)
    steps.setdefault("TOTAL", []).append((marks[-1][1] - marks[0][1]) / 1000)
variants = sorted(by_variant)
labels = list(dict.fromkeys(l for v in variants for l in by_variant[v]))
print(f"{'step':26}" + "".join(f"{v:>16}" for v in variants))
for label in labels:
    row = [by_variant[v].get(label) for v in variants]
    print(f"{label:26}" + "".join(f"{statistics.median(r):16.2f}" if r else f"{'-':>16}" for r in row))
print("runs:", {v: len(by_variant[v]["TOTAL"]) for v in variants})
