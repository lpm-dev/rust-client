#!/bin/bash
# Reproduces the Node version reuse measurements: up-to-date, installed-cache-gone
# and warm installs of T3 and native-sharp, #890 against this change and Bun.
set -euo pipefail
ROOT=$(cd "$(dirname "$0")" && pwd)
BASELINE=${BASELINE:?path to the #890 lpm-rs}
CHANGE=${CHANGE:?path to the changed lpm-rs}
BUN=${BUN:?path to bun}
FIXTURES=${FIXTURES:?directory with t3/ and native-sharp/ package.json fixtures}
OUT=$ROOT/results
mkdir -p "$OUT"

run_script() { # <file> <binary> <work> <mode>
cat > "$1" <<SCRIPT
#!/bin/bash
export HOME=$3/home NO_COLOR=1 LPM_HOME=$3/lpm-home LPM_STORE_VERSION=v2
if [ "$4" = pipeline ]; then export CI=1; args=(--json install --no-security-summary --no-skills --no-editor-setup); else unset CI; args=(--json install); fi
cd $3/project && exec "$2" "\${args[@]}" >/dev/null
SCRIPT
chmod +x "$1"
}

for fixture in t3 native-sharp; do
  base=$ROOT/work/$fixture/base
  rm -rf "$ROOT/work/$fixture"; mkdir -p "$base/project" "$base/home" "$base/lpm-home"
  cp "$FIXTURES/$fixture/package.json" "$base/project/"
  (cd "$base/project" && HOME=$base/home CI=1 NO_COLOR=1 LPM_HOME=$base/lpm-home LPM_STORE_VERSION=v2 \
    "$BASELINE" --json install --no-security-summary --no-skills --no-editor-setup >/dev/null)
  for variant in baseline change; do
    work=$ROOT/work/$fixture/$variant
    cp -cR "$base" "$work"
    binary=$BASELINE; [ "$variant" = change ] && binary=$CHANGE
    for mode in pipeline lane; do run_script "$ROOT/work/$fixture/$variant-$mode.sh" "$binary" "$work" "$mode"; "$ROOT/work/$fixture/$variant-$mode.sh"; done
  done
  bun=$ROOT/work/$fixture/bun
  mkdir -p "$bun/project" "$bun/home"; cp "$FIXTURES/$fixture/package.json" "$bun/project/"
  (cd "$bun/project" && HOME=$bun/home BUN_INSTALL_CACHE_DIR=$bun/home/.bun/install/cache CI=1 "$BUN" install --ignore-scripts >/dev/null 2>&1)
  printf '#!/bin/bash\ncd %s/project && HOME=%s/home BUN_INSTALL_CACHE_DIR=%s/home/.bun/install/cache CI=1 exec %s install --ignore-scripts >/dev/null 2>&1\n' "$bun" "$bun" "$bun" "$BUN" > "$ROOT/work/$fixture/bun.sh"
  chmod +x "$ROOT/work/$fixture/bun.sh"

  w=$ROOT/work/$fixture
  hyperfine -N -w 5 -r 40 --export-json "$OUT/$fixture-up-to-date.json" \
    -n baseline-pipeline "$w/baseline-pipeline.sh" -n change-pipeline "$w/change-pipeline.sh" \
    -n baseline-lane "$w/baseline-lane.sh" -n change-lane "$w/change-lane.sh" -n bun "$w/bun.sh"
done

w=$ROOT/work/t3
hyperfine -N -w 3 -r 30 --export-json "$OUT/t3-installed-cache-gone.json" \
  -n baseline --prepare "rm -rf $w/baseline/lpm-home/cache" "$w/baseline-pipeline.sh" \
  -n change --prepare "rm -rf $w/change/lpm-home/cache" "$w/change-pipeline.sh"
hyperfine -N -w 2 -r 30 --export-json "$OUT/t3-node-modules-removed.json" \
  -n baseline --prepare "rm -rf $w/baseline/project/node_modules" "$w/baseline-pipeline.sh" \
  -n change --prepare "rm -rf $w/change/project/node_modules" "$w/change-pipeline.sh"
python3 - "$w" "$OUT/t3-ci-warm-paired.json" <<'PY'
import json, shutil, statistics, subprocess, sys, time
work, out = sys.argv[1], sys.argv[2]
def run(variant):
    for name in ("node_modules", ".lpm"):
        shutil.rmtree(f"{work}/{variant}/project/{name}", ignore_errors=True)
    started = time.perf_counter()
    subprocess.run([f"{work}/{variant}-pipeline.sh"], check=True)
    return (time.perf_counter() - started) * 1e3
for variant in ("baseline", "change"):
    run(variant); run(variant)
rounds = []
for index in range(60):
    order = ("baseline", "change") if index % 2 == 0 else ("change", "baseline")
    rounds.append({variant: run(variant) for variant in order})
deltas = [r["change"] - r["baseline"] for r in rounds]
summary = {
    "rounds": rounds,
    "baseline_median_ms": statistics.median(r["baseline"] for r in rounds),
    "change_median_ms": statistics.median(r["change"] for r in rounds),
    "paired_median_delta_ms": statistics.median(deltas),
    "change_faster_rounds": sum(delta < 0 for delta in deltas),
}
json.dump(summary, open(out, "w"), indent=1)
print({k: v for k, v in summary.items() if k != "rounds"})
PY
