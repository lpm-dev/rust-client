use std::time::Instant;
fn main() {
    let cwd = std::path::PathBuf::from(std::env::args().nth(1).unwrap());
    let path = std::env::join_paths(std::iter::once(cwd.join("node_modules/.bin")).chain(std::env::split_paths(&std::env::var_os("PATH").unwrap()))).unwrap();
    let mut samples = Vec::new();
    for _ in 0..300 {
        let started = Instant::now();
        std::hint::black_box(lpm_runtime::effective::probe_node_fingerprint_on_path(&cwd, &path).unwrap());
        samples.push(started.elapsed().as_secs_f64() * 1e6);
    }
    samples.sort_by(f64::total_cmp);
    println!("fingerprint: median {:.0} us, p90 {:.0} us", samples[150], samples[270]);
}
