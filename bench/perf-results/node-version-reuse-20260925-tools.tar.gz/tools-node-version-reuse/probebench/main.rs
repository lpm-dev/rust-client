#[allow(dead_code)]
mod old;
use std::process::Command;
use std::time::{Duration, Instant};
fn main() {
    let node = std::env::args().nth(1).unwrap();
    let (mut before, mut after) = (Vec::new(), Vec::new());
    for round in 0..400 {
        let mut command = Command::new(&node);
        command.arg("--version");
        let started = Instant::now();
        let output = if round % 2 == 0 {
            old::output_capped(&mut command, Duration::from_secs(2), 4096)
        } else {
            lpm_common::process_output::output_capped(&mut command, Duration::from_secs(2), 4096)
        }
        .unwrap();
        assert!(output.status.success());
        let ms = started.elapsed().as_secs_f64() * 1e3;
        if round % 2 == 0 { before.push(ms) } else { after.push(ms) }
    }
    for (name, mut samples) in [("2 ms polling", before), ("event-driven", after)] {
        samples.sort_by(f64::total_cmp);
        println!("{name}: median {:.2} ms, p90 {:.2} ms", samples[samples.len() / 2], samples[samples.len() * 9 / 10]);
    }
}
