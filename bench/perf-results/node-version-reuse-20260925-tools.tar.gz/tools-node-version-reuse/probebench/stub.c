#include <stdio.h>
int main(void){puts("v24.19.0");return 0;}
