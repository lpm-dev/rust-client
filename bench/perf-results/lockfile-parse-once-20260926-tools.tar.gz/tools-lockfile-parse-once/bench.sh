#!/bin/bash
# Lockfile parse reuse and single baseline index: #891 against this change.
set -euo pipefail
ROOT=$(cd "$(dirname "$0")" && pwd)
BASELINE=${BASELINE:?path to the #891 lpm-rs}
CHANGE=${CHANGE:?path to the changed lpm-rs}
FIXTURES=${FIXTURES:?directory with t3/ and vite-react/ package.json fixtures}
OUT=$ROOT/results
mkdir -p "$OUT"

for fixture in t3 vite-react; do
  base=$ROOT/work/$fixture/base
  rm -rf "$ROOT/work/$fixture"; mkdir -p "$base/project" "$base/home" "$base/lpm-home"
  cp "$FIXTURES/$fixture/package.json" "$base/project/"
  (cd "$base/project" && HOME=$base/home CI=1 NO_COLOR=1 LPM_HOME=$base/lpm-home LPM_STORE_VERSION=v2 \
    "$BASELINE" --json install --no-security-summary --no-skills --no-editor-setup >/dev/null)
  for variant in baseline change; do
    cp -cR "$base" "$ROOT/work/$fixture/$variant"
  done
done

python3 - "$ROOT/work" "$OUT" "$BASELINE" "$CHANGE" <<'PY'
import json, os, shutil, statistics, subprocess, sys, time
work, out, baseline, change = sys.argv[1:5]
binaries = {"baseline": baseline, "change": change}

def install(fixture, variant, reset):
    root = f"{work}/{fixture}/{variant}"
    project = f"{root}/project"
    for name in reset:
        target = f"{root}/lpm-home/cache" if name == "cache" else f"{project}/{name}"
        shutil.rmtree(target, ignore_errors=True)
    env = dict(os.environ, HOME=f"{root}/home", CI="1", NO_COLOR="1",
               LPM_HOME=f"{root}/lpm-home", LPM_STORE_VERSION="v2")
    started = time.perf_counter()
    result = subprocess.run([binaries[variant], "--json", "install", "--no-security-summary",
                             "--no-skills", "--no-editor-setup", "--timing"],
                            cwd=project, env=env, capture_output=True, text=True, check=True)
    wall = (time.perf_counter() - started) * 1e3
    return wall, json.loads(result.stdout)["timing"]["total_ms"]

def p95(values):
    values = sorted(values)
    return values[min(len(values) - 1, -(-95 * len(values) // 100) - 1)]

states = [
    ("t3", "up-to-date", ()),
    ("t3", "package-cache-removed", ("cache",)),
    ("t3", "node-modules-removed", ("node_modules",)),
    ("t3", "ci-warm", ("node_modules", ".lpm")),
    ("vite-react", "ci-warm", ("node_modules", ".lpm")),
]
summary = {}
for fixture, state, reset in states:
    rounds = 40 if state in ("up-to-date", "package-cache-removed") else 30
    for variant in binaries:
        install(fixture, variant, reset); install(fixture, variant, reset)
    samples = {variant: {"wall_ms": [], "internal_ms": []} for variant in binaries}
    deltas = []
    for index in range(rounds):
        order = ("baseline", "change") if index % 2 == 0 else ("change", "baseline")
        pair = {}
        for variant in order:
            wall, internal = install(fixture, variant, reset)
            samples[variant]["wall_ms"].append(wall)
            samples[variant]["internal_ms"].append(internal)
            pair[variant] = wall
        deltas.append(pair["change"] - pair["baseline"])
    key = f"{fixture}/{state}"
    summary[key] = {
        variant: {
            "wall_median_ms": round(statistics.median(values["wall_ms"]), 2),
            "wall_p95_ms": round(p95(values["wall_ms"]), 2),
            "internal_median_ms": statistics.median(values["internal_ms"]),
        }
        for variant, values in samples.items()
    }
    summary[key]["paired_wall_median_delta_ms"] = round(statistics.median(deltas), 2)
    summary[key]["change_faster_rounds"] = sum(delta < 0 for delta in deltas)
    summary[key]["rounds"] = rounds
    summary[key]["samples"] = samples
    print(key, {k: v for k, v in summary[key].items() if k != "samples"})
json.dump(summary, open(f"{out}/paired.json", "w"), indent=1)
PY
