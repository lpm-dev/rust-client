#[global_allocator]
static GLOBAL: mimalloc::MiMalloc = mimalloc::MiMalloc;
use std::time::Instant;
fn bench<T>(name: &str, mut f: impl FnMut() -> T) {
    for _ in 0..5 { std::hint::black_box(f()); }
    let mut v: Vec<f64> = (0..200).map(|_| { let t = Instant::now(); std::hint::black_box(f()); t.elapsed().as_secs_f64() * 1e3 }).collect();
    v.sort_by(f64::total_cmp);
    println!("{name:45} median {:.3} ms", v[100]);
}
fn main() {
    let project = std::path::PathBuf::from(std::env::args().nth(1).unwrap());
    let path = project.join("lpm.lock");
    let content = std::fs::read_to_string(&path).unwrap();
    let parsed = lpm_lockfile::Lockfile::from_toml(&content).unwrap();
    bench("read file (capped)", || lpm_common::read_text_file_capped(&path, 64 << 20).unwrap());
    bench("compare content", || { let c = content.clone(); c == content });
    bench("Lockfile::from_toml (parse+validate)", || lpm_lockfile::Lockfile::from_toml(&content).unwrap());
    bench("Lockfile::clone", || parsed.clone());

    bench("to_toml", || parsed.to_toml().unwrap());
    bench("read_for_project (full)", || lpm_lockfile::Lockfile::read_for_project(&project).unwrap());
    let normalized = parsed.to_toml().unwrap();
    println!("to_toml == raw content: {}", normalized == content);
}
