"""Live first installs of the T3 fixture from registry.npmjs.org on this Mac.
Each install starts from an empty home, cache and store; variants alternate in
balanced order. Usage: python3 live_ab.py ROUNDS VARIANT..."""
import json
import os
import shutil
import statistics
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.abspath(__file__))
BINARY = os.path.join(ROOT, "binaries", "lpm-exp-macos")
FIXTURE = os.path.join(ROOT, "fixture", "package.json")
WORK = os.path.join(ROOT, "live-work")
VARIANTS = {
    "shared": {},
    "h1-pool": {"LPM_HTTP": "h1-pool"},
    "h1-fanout-48": {"LPM_HTTP": "h1-pool", "LPM_NPM_FANOUT": "48"},
    "h1-fanout-24": {"LPM_HTTP": "h1-pool", "LPM_NPM_FANOUT": "24"},
    "spread-all-8": {"LPM_EXPERIMENT_TARBALL_LANES": "spread-all-8"},
    "baseline": {},
    "lanes": {},
}
BINARIES = {
    "baseline": "/Users/tolga/Documents/Projects/lpm-dev/performance-runs/20260925/npm-token/binaries/lpm-889",
    "lanes": os.path.join(ROOT, "binaries", "lpm-macos-lanes"),
}


def install(variant):
    shutil.rmtree(WORK, ignore_errors=True)
    for directory in ("home", "lpm-home", "project"):
        os.makedirs(os.path.join(WORK, directory))
    shutil.copy(FIXTURE, os.path.join(WORK, "project", "package.json"))
    env = {
        "PATH": os.environ["PATH"],
        "TMPDIR": os.environ.get("TMPDIR", "/tmp"),
        "HOME": os.path.join(WORK, "home"),
        "LPM_HOME": os.path.join(WORK, "lpm-home"),
        "LPM_STORE_VERSION": "v2",
        "LPM_NO_UPDATE_CHECK": "1",
        "CI": "1",
        "NO_COLOR": "1",
        **VARIANTS[variant],
    }
    started = time.perf_counter()
    result = subprocess.run(
        [BINARIES.get(variant, BINARY), "--json", "install", "--timing", "--no-security-summary", "--no-skills", "--no-editor-setup"],
        cwd=os.path.join(WORK, "project"), env=env, capture_output=True, text=True,
    )
    wall = (time.perf_counter() - started) * 1e3
    assert result.returncode == 0, result.stderr[-2000:]
    waterfall = json.loads(result.stdout).get("timing", {}).get("waterfall", {})
    return {"variant": variant, "wall_ms": wall, "resolve_ms": waterfall.get("resolve_ms"), "fetch_ms": waterfall.get("fetch_ms")}


def nearest_rank(values, percentile):
    ordered = sorted(values)
    return ordered[int(max(1, -(-len(ordered) * percentile // 100))) - 1]


def main():
    rounds = int(sys.argv[1])
    variants = sys.argv[2:]
    rows = []
    for variant in variants:
        install(variant)
    for sample in range(1, rounds + 1):
        order = variants[(sample - 1) % len(variants):] + variants[: (sample - 1) % len(variants)]
        if sample % 2 == 0:
            order.reverse()
        for variant in order:
            row = install(variant)
            row["sample"] = sample
            rows.append(row)
            json.dump(rows, open(os.path.join(ROOT, "results", f"live-rows-{'-'.join(sys.argv[2:])}.json"), "w"), indent=1)
        print(f"round {sample}/{rounds}", flush=True)
    for variant in variants:
        walls = [r["wall_ms"] for r in rows if r["variant"] == variant]
        resolves = [r["resolve_ms"] for r in rows if r["variant"] == variant and r["resolve_ms"] is not None]
        line = f"{variant:13} median {statistics.median(walls):7.0f} p95 {nearest_rank(walls, 95):7.0f} resolve {statistics.median(resolves) if resolves else '-'}"
        if variant != variants[0]:
            pairs = [
                r["wall_ms"] - next(b["wall_ms"] for b in rows if b["variant"] == variants[0] and b["sample"] == r["sample"])
                for r in rows if r["variant"] == variant
            ]
            line += f" paired {statistics.median(pairs):+.0f} ({sum(p < 0 for p in pairs)}/{len(pairs)})"
        print(line)
    shutil.rmtree(WORK, ignore_errors=True)


if __name__ == "__main__":
    main()
