#!/bin/bash
# run.sh capture | cells SAMPLES
set -euo pipefail
B=/Users/tolga/Documents/Projects/lpm-dev/performance-runs/20260925/tarball-lanes
NET=lpm-lanes
IMAGE=node:24-bookworm-slim
docker network create $NET >/dev/null 2>&1 || true

server() {
  docker rm -f lanes-server >/dev/null 2>&1 || true
  docker run -d --name lanes-server --network $NET --network-alias server --cap-add NET_ADMIN \
    --sysctl net.ipv4.tcp_wmem="4096 65536 67108864" -v "$B":/bench $IMAGE sh -c \
    "apt-get update -qq >/dev/null && apt-get install -y -qq iproute2 ethtool openssl >/dev/null 2>&1 && cd /bench && node server.mjs /bench/capture/frozen-registry /bench/ca $1 > /bench/results/server-\$(date +%s).log 2>&1" >/dev/null
  for _ in $(seq 1 180); do
    docker exec lanes-server node -e "require('net').connect(8080,'127.0.0.1').on('connect',()=>process.exit(0)).on('error',()=>process.exit(1))" >/dev/null 2>&1 && return
    sleep 1
  done
  echo "server did not start" >&2; exit 1
}

client() {
  docker rm -f lanes-client >/dev/null 2>&1 || true
  docker run -d --name lanes-client --network $NET --cap-add NET_ADMIN \
    --sysctl net.ipv4.tcp_rmem="4096 131072 $1" -v "$B":/bench $IMAGE sleep infinity >/dev/null
  docker exec lanes-client sh -c 'apt-get update -qq >/dev/null && apt-get install -y -qq iproute2 ethtool libdbus-1-3 >/dev/null 2>&1'
}

shape() { # one-way delay ms, rate mbit
  docker exec lanes-server /bench/shape.sh "$1" "$2"
  docker exec lanes-client /bench/shape.sh "$1" "$2"
}

if [ "$1" = capture ]; then
  rm -rf "$B/ca"; mkdir -p "$B/capture/frozen-registry"
  server --capture
  client 4194304
  docker exec -w /bench lanes-client node driver.mjs capture 2 /bench/results/capture-rows.json --capture
  docker exec lanes-client node -e "fetch('http://server:8080/_control',{method:'POST',body:JSON.stringify({frozen:true,phase:'frozen'})}).then(async r=>{if(!r.ok)throw new Error(await r.text())})"
  docker exec lanes-client node -e "fetch('http://server:8080/_status').then(r=>r.json()).then(s=>console.log(JSON.stringify({frozen:s.frozen,fixtures:s.fixtures,misses:s.misses.length,rejected:s.rejected.length,tunnels:s.tunnels.length})))"
  shasum -a 256 "$B/capture/frozen-registry/manifest.json" | awk '{printf "{\"sha256\":\"%s\"}\n", $1}' > "$B/capture/capture-manifest-sha256.json"
  docker rm -f lanes-server lanes-client >/dev/null
  exit 0
fi

if [ "$1" = probe ]; then
  server ""
  client 4194304
  docker exec -e VARIANTS="${2:-}" -w /bench lanes-client node driver.mjs probe 1 /bench/results/probe-rows.json
  docker exec lanes-client node -e "fetch('http://server:8080/_status').then(r=>r.json()).then(s=>{const v={};for(const e of s.events){const k=e.phase.replace(/^(gate|sample)-probe-(1-)?/,'')+' h'+e.http_version;v[k]=(v[k]||0)+1};const t={};for(const x of s.tunnels){if(!x.phase.startsWith('sample'))continue;const e=t[x.phase]??={count:0,carrying_1mb:0,down_mb:0,largest_share:0,_max:0};e.count++;e.down_mb+=x.down/1e6;if(x.down>1e6)e.carrying_1mb++;e._max=Math.max(e._max,x.down)};for(const e of Object.values(t)){e.largest_share=+(e._max/1e6/e.down_mb).toFixed(2);e.down_mb=+e.down_mb.toFixed(1);delete e._max};console.log(JSON.stringify({requests:v,tunnels:t,rejected:s.rejected,misses:s.misses.length},null,1))})"
  docker rm -f lanes-server lanes-client >/dev/null
  exit 0
fi

SAMPLES=$2
server ""
# cell: name one-way-delay rate-mbit rmem
while read -r name delay rate rmem; do
  [ -z "$name" ] && continue
  echo "$(date '+%H:%M:%S') cell $name"
  client "$rmem"
  shape "$delay" "$rate"
  docker exec -w /bench lanes-client node driver.mjs "$name" "$SAMPLES" "/bench/results/rows-$name.json"
done < "$B/cells.txt"
docker exec lanes-client node -e "fetch('http://server:8080/_status').then(r=>r.json()).then(s=>require('fs').writeFileSync('/bench/results/proxy-status.json',JSON.stringify({frozen:s.frozen,fixtures:s.fixtures,misses:s.misses,rejected:s.rejected,tunnels:s.tunnels,events:s.events.map(e=>({phase:e.phase,request:e.request,bytes:e.bytes,wire_bytes:e.wire_bytes,http_version:e.http_version}))})))"
docker rm -f lanes-server lanes-client >/dev/null
echo "$(date '+%H:%M:%S') done"
