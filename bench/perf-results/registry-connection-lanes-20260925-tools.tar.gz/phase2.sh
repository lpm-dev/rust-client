#!/bin/bash
set -u
B=/Users/tolga/Documents/Projects/lpm-dev/performance-runs/20260925/tarball-lanes
V=shared,h1-pool,spread-4,spread-all-4,spread-all-8
run() { echo "$(date '+%H:%M:%S') start $1"; LPM_BENCH_TIMING=1 "$B/run2.sh" "$@" "$V" >> "$B/results/phase2.log" 2>&1 || echo "$(date '+%H:%M:%S') FAILED $1"; }
run p2-rtt50-bigbuf 25 1000 4194304 bigbuf 10
run p2-rtt50-lowat 25 1000 4194304 lowat 10
run p2-rtt50-default 25 1000 4194304 default 10
run p2-rtt20-lowat 10 1000 4194304 lowat 10
run p2-rtt0-lowat 0 1000 4194304 lowat 10
run p2-rtt100-lowat 50 1000 4194304 lowat 10
echo "$(date '+%H:%M:%S') phase2 done"
