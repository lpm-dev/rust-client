#!/bin/bash
B=/Users/tolga/Documents/Projects/lpm-dev/performance-runs/20260925/tarball-lanes
until grep -q "phase2b done" "$B/results/phase2-driver.log"; do sleep 10; done
V=shared,h1-pool,spread-all-8,spread-all-16,spread-all-32
for cell in "p3-rtt20-lowat 10" "p3-rtt50-lowat 25" "p3-rtt100-lowat 50"; do
  set -- $cell
  echo "$(date '+%H:%M:%S') start $1" >> "$B/results/phase2-driver.log"
  LPM_BENCH_TIMING=1 "$B/run2b.sh" "$1" "$2" 1000 4194304 lowat 10 "$V" >> "$B/results/phase2.log" 2>&1 || echo "$(date '+%H:%M:%S') FAILED $1" >> "$B/results/phase2-driver.log"
done
echo "$(date '+%H:%M:%S') phase3 done" >> "$B/results/phase2-driver.log"
