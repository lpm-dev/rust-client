"""Summarize tarball-lane rows: nearest-rank medians/p95, paired deltas vs shared,
per-phase waterfall medians, and connection use from the proxy log."""
import glob
import json
import os
import statistics

ROOT = os.path.dirname(os.path.abspath(__file__))
REFERENCE = "shared"


def nearest_rank(values, percentile):
    ordered = sorted(values)
    rank = max(1, -(-len(ordered) * percentile // 100))
    return ordered[int(rank) - 1]


def connection_use(status):
    use = {}
    for tunnel in status.get("tunnels", []):
        phase = tunnel["phase"]
        if not phase.startswith("sample-"):
            continue
        entry = use.setdefault(phase, {"count": 0, "busy": 0, "down": 0, "max": 0})
        entry["count"] += 1
        entry["down"] += tunnel["down"]
        entry["busy"] += tunnel["down"] > 1_000_000
        entry["max"] = max(entry["max"], tunnel["down"])
    return use


def main():
    status_path = os.path.join(ROOT, "results", "proxy-status.json")
    status = json.load(open(status_path)) if os.path.exists(status_path) else {}
    use = connection_use(status)
    summary = {"cells": {}, "misses": len(status.get("misses", [])), "rejected": len(status.get("rejected", []))}
    for path in sorted(glob.glob(os.path.join(ROOT, "results", "rows-*.json"))):
        rows = json.load(open(path))
        cell = rows[0]["cell"]
        by_variant = {}
        for row in rows:
            by_variant.setdefault(row["variant"], {})[row["sample"]] = row
        cell_summary = {}
        for variant, samples in by_variant.items():
            walls = [row["wall_ms"] for row in samples.values()]
            entry = {
                "n": len(walls),
                "failed": sum(not row["ok"] for row in samples.values()),
                "median_ms": round(statistics.median(walls), 1),
                "p95_ms": round(nearest_rank(walls, 95), 1),
            }
            if variant != REFERENCE and REFERENCE in by_variant:
                pairs = [
                    samples[s]["wall_ms"] - by_variant[REFERENCE][s]["wall_ms"]
                    for s in samples
                    if s in by_variant[REFERENCE]
                ]
                entry["paired_ms"] = round(statistics.median(pairs), 1)
                entry["faster"] = f"{sum(d < 0 for d in pairs)}/{len(pairs)}"
            waterfalls = [row["waterfall"] for row in samples.values() if row.get("waterfall")]
            if waterfalls:
                keys = [k for k, v in waterfalls[0].items() if isinstance(v, (int, float))]
                entry["waterfall_median"] = {
                    k: round(statistics.median(w.get(k, 0) for w in waterfalls), 1) for k in keys
                }
            phases = [use[row["phase"]] for row in samples.values() if row["phase"] in use]
            if phases:
                entry["connections"] = round(statistics.median(p["count"] for p in phases), 1)
                entry["busy_connections"] = round(statistics.median(p["busy"] for p in phases), 1)
                entry["largest_share"] = round(statistics.median(p["max"] / p["down"] for p in phases if p["down"]), 2)
            cell_summary[variant] = entry
        summary["cells"][cell] = cell_summary
    json.dump(summary, open(os.path.join(ROOT, "results", "summary.json"), "w"), indent=2)
    for cell, variants in summary["cells"].items():
        print(f"\n{cell}")
        for variant, e in variants.items():
            extra = f" paired {e['paired_ms']:+.0f} ({e['faster']})" if "paired_ms" in e else ""
            conn = f" conns {e.get('connections')} busy {e.get('busy_connections')} top {e.get('largest_share')}" if "connections" in e else ""
            print(f"  {variant:11} n={e['n']:2} median {e['median_ms']:8.0f} p95 {e['p95_ms']:8.0f}{extra}{conn}")
    print("\nmisses", summary["misses"], "rejected", summary["rejected"])


if __name__ == "__main__":
    main()
