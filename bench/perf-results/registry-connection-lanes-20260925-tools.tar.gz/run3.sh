#!/bin/bash
# run2.sh NAME ONE_WAY_DELAY RATE_MBIT CLIENT_RMEM SERVER_PROFILE SAMPLES [VARIANTS]
# SERVER_PROFILE: bigbuf (64 MiB send buffer), default (kernel default), lowat (64 MiB + tcp_notsent_lowat 128 KiB)
set -euo pipefail
B=/Users/tolga/Documents/Projects/lpm-dev/performance-runs/20260925/tarball-lanes
NET=lpm-lanes
IMAGE=node:24-bookworm-slim
name=$1; delay=$2; rate=$3; rmem=$4; profile=$5; samples=$6; variants=${7:-}
case "$profile" in
  bigbuf) sysctls=(--sysctl net.ipv4.tcp_wmem="4096 65536 67108864") ;;
  default) sysctls=() ;;
  lowat) sysctls=(--sysctl net.ipv4.tcp_wmem="4096 65536 67108864" --sysctl net.ipv4.tcp_notsent_lowat=131072) ;;
  *) echo "unknown profile $profile" >&2; exit 2 ;;
esac
docker network create $NET >/dev/null 2>&1 || true
docker rm -f lanes-server lanes-client >/dev/null 2>&1 || true
docker run -d --name lanes-server --network $NET --network-alias server --cap-add NET_ADMIN ${sysctls[@]+"${sysctls[@]}"} \
  -v "$B":/bench $IMAGE sh -c "apt-get update -qq >/dev/null && apt-get install -y -qq iproute2 ethtool openssl >/dev/null 2>&1 && cd /bench && node server.mjs /bench/capture/frozen-registry /bench/ca > /bench/results/server-\$(date +%s).log 2>&1" >/dev/null
for _ in $(seq 1 180); do
  docker exec lanes-server node -e "require('net').connect(8080,'127.0.0.1').on('connect',()=>process.exit(0)).on('error',()=>process.exit(1))" >/dev/null 2>&1 && break
  sleep 1
done
docker run -d --name lanes-client --network $NET --cap-add NET_ADMIN --sysctl net.ipv4.tcp_rmem="4096 131072 $rmem" -v "$B":/bench $IMAGE sleep infinity >/dev/null
docker exec lanes-client sh -c 'apt-get update -qq >/dev/null && apt-get install -y -qq iproute2 ethtool libdbus-1-3 curl >/dev/null 2>&1'
docker exec lanes-server /bench/shape.sh "$delay" "$rate"
docker exec lanes-client /bench/shape.sh "$delay" "$rate"
docker exec -e VARIANTS="$variants" -e LPM_BENCH_TIMING="${LPM_BENCH_TIMING:-0}" -w /bench lanes-client node driver3.mjs "$name" "$samples" "/bench/results/diag-$name.json"
docker exec lanes-server sh -c 'tc -s qdisc show dev eth0' > "$B/results/diag-$name-server-qdisc.txt"
docker exec lanes-client node -e "fetch('http://server:8080/_status').then(r=>r.json()).then(s=>require('fs').writeFileSync('/bench/results/diag-$name-status.json',JSON.stringify({misses:s.misses,rejected:s.rejected,tunnels:s.tunnels})))"
docker rm -f lanes-server lanes-client >/dev/null
