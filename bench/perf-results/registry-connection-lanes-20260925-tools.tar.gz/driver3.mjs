// Client-side driver: first installs of the T3 fixture through the replay proxy.
// Usage: node driver.mjs CELL SAMPLES OUT_JSON [--capture]
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const [cell, samplesArg, output] = process.argv.slice(2);
const capture = process.argv.includes('--capture');
const samples = Number(samplesArg);
const proxy = 'http://server:8080';
const fixture = fs.readFileSync('/bench/fixture/package.json');
const VARIANTS = [
  { id: 'baseline', env: {}, binary: '/bench/binaries/lpm-linux-base' },
  { id: 'lanes', env: {}, binary: '/bench/binaries/lpm-linux-lanes' },
];

const only = process.env.VARIANTS?.split(',').filter(Boolean);
if (only?.length) VARIANTS.splice(0, VARIANTS.length, ...VARIANTS.filter(variant => only.includes(variant.id)));

// The control server may close an idle keep-alive socket as it is reused; retry those.
async function control(value) {
  for (let attempt = 1; ; attempt++) {
    try {
      const response = await fetch(`${proxy}/_control`, { method: 'POST', body: JSON.stringify(value) });
      if (!response.ok) throw new Error(`control failed: ${response.status} ${await response.text()}`);
      return;
    } catch (error) {
      if (attempt === 5 || error.cause?.code !== 'UND_ERR_SOCKET') throw error;
    }
  }
}

function freshRoot() {
  const root = '/work/root';
  fs.rmSync(root, { recursive: true, force: true });
  for (const dir of ['home', 'lpm-home', 'project']) fs.mkdirSync(path.join(root, dir), { recursive: true });
  fs.writeFileSync(path.join(root, 'project', 'package.json'), fixture);
  fs.writeFileSync(path.join(root, 'home', '.npmrc'), '//registry.npmjs.org/:cafile=/bench/ca/ca.pem\n');
  return root;
}

async function serverTcp() {
  for (let attempt = 1; ; attempt++) {
    try { return await (await fetch(`${proxy}/_net`)).json(); }
    catch (error) { if (attempt === 5) throw error; }
  }
}

function clientTcp() {
  const [names, values] = fs.readFileSync('/proc/net/snmp', 'utf8').split('\n').filter(line => line.startsWith('Tcp:')).map(line => line.split(/\s+/).slice(1));
  return Object.fromEntries(names.map((name, index) => [name, Number(values[index])]));
}

function install(variant) {
  const root = freshRoot();
  const env = {
    PATH: process.env.PATH,
    HOME: path.join(root, 'home'),
    LPM_HOME: path.join(root, 'lpm-home'),
    LPM_STORE_VERSION: 'v2',
    CI: '1',
    NO_COLOR: '1',
    LPM_NO_UPDATE_CHECK: '1',
    NPM_CONFIG_USERCONFIG: path.join(root, 'home', '.npmrc'),
    HTTPS_PROXY: proxy, https_proxy: proxy, HTTP_PROXY: proxy, http_proxy: proxy,
    NO_PROXY: '', no_proxy: '',
    ...variant.env,
  };
  const started = process.hrtime.bigint();
  const args = ['--json', 'install', '--no-security-summary', '--no-skills', '--no-editor-setup'];
  if (process.env.LPM_BENCH_TIMING === '1') args.push('--timing');
  const result = spawnSync(variant.binary, args,
    { cwd: path.join(root, 'project'), env, encoding: 'utf8', maxBuffer: 256 * 1024 * 1024, timeout: 300000 });
  const wallMs = Number(process.hrtime.bigint() - started) / 1e6;
  let parsed;
  try { parsed = JSON.parse(result.stdout); } catch { parsed = undefined; }
  const ok = result.status === 0 && fs.existsSync(path.join(root, 'project', 'node_modules', 'next', 'package.json'));
  return {
    ok, wall_ms: wallMs, status: result.status,
    stderr_tail: ok ? undefined : (result.stderr ?? '').slice(-2000),
    waterfall: parsed?.timing?.waterfall,
    packages: parsed?.packages?.length ?? parsed?.summary?.packages ?? undefined,
  };
}

function order(sample) {
  const rotated = VARIANTS.map((_, index) => VARIANTS[(index + Math.floor((sample - 1) / 2)) % VARIANTS.length]);
  return sample % 2 === 0 ? rotated.reverse() : rotated;
}

const rows = [];
for (const variant of VARIANTS) {
  await control({ phase: `gate-${cell}-${variant.id}` });
  const gate = install(variant);
  if (!gate.ok) throw new Error(`gate failed for ${variant.id}: ${gate.stderr_tail}`);
}
for (let sample = 1; sample <= samples; sample++) {
  for (const variant of order(sample)) {
    const phase = `sample-${cell}-${sample}-${variant.id}`;
    await control({ phase });
    const serverBefore = await serverTcp();
    const clientBefore = clientTcp();
    const result = install(variant);
    const serverAfter = await serverTcp();
    const clientAfter = clientTcp();
    result.server_retransmits = serverAfter.RetransSegs - serverBefore.RetransSegs;
    result.server_out_segments = serverAfter.OutSegs - serverBefore.OutSegs;
    result.client_retransmits = clientAfter.RetransSegs - clientBefore.RetransSegs;
    rows.push({ cell, sample, variant: variant.id, phase, ...result });
    fs.writeFileSync(output, JSON.stringify(rows, null, 1));
    if (!result.ok) throw new Error(`install failed: ${phase}: ${result.stderr_tail}`);
  }
  console.log(`${new Date().toISOString()} ${cell} sample ${sample}/${samples}`);
}
await control({ phase: `idle-${cell}` });
