// Serve the replay proxy on 0.0.0.0:8080 for the client container.
// Usage: node server.mjs CAPTURE_DIR CA_OUT_DIR [--capture]
import fs from 'node:fs';
import path from 'node:path';
import { createReplayProxy } from './replay-proxy.mjs';
import { benchmarkTls } from './tls.mjs';

const [directory, caOut] = process.argv.slice(2);
const capture = process.argv.includes('--capture');
const anchor = path.join(directory, '..', 'capture-manifest-sha256.json');
const expectedManifestSha256 = !capture && fs.existsSync(anchor) ? JSON.parse(fs.readFileSync(anchor)).sha256 : undefined;
fs.mkdirSync(caOut, { recursive: true });
const tls = benchmarkTls(caOut);
fs.copyFileSync(tls.ca, path.join(caOut, 'ca.pem'));
const proxy = await createReplayProxy({ ...tls, directory, expectedManifestSha256, host: '0.0.0.0', port: 8080 });
console.log(JSON.stringify({ url: proxy.url, frozen: proxy.status().frozen, fixtures: proxy.status().fixtures }));
process.on('SIGTERM', async () => { await proxy.close(); tls.close(); process.exit(0); });
