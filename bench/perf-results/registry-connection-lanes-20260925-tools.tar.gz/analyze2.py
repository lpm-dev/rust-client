"""Summarize phase-2 diagnostic runs: wall and waterfall medians, paired deltas vs
shared, server retransmits, and connection use per variant."""
import glob
import json
import os
import statistics
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
REFERENCE = os.environ.get("REFERENCE", "shared")


def nearest_rank(values, percentile):
    ordered = sorted(values)
    return ordered[int(max(1, -(-len(ordered) * percentile // 100))) - 1]


def summarize(path):
    rows = json.load(open(path))
    status_path = path.replace(".json", "-status.json")
    tunnels = json.load(open(status_path))["tunnels"] if os.path.exists(status_path) else []
    use = {}
    for tunnel in tunnels:
        entry = use.setdefault(tunnel["phase"], {"count": 0, "busy": 0})
        entry["count"] += 1
        entry["busy"] += tunnel["down"] > 1_000_000
    by_variant = {}
    for row in rows:
        by_variant.setdefault(row["variant"], {})[row["sample"]] = row
    result = {}
    for variant, samples in by_variant.items():
        walls = [row["wall_ms"] for row in samples.values()]
        waterfalls = [row["waterfall"] for row in samples.values() if row.get("waterfall")]
        entry = {
            "n": len(walls),
            "median_ms": round(statistics.median(walls)),
            "p95_ms": round(nearest_rank(walls, 95)),
            "resolve_ms": round(statistics.median(w["resolve_ms"] for w in waterfalls)) if waterfalls else None,
            "fetch_ms": round(statistics.median(w["fetch_ms"] for w in waterfalls)) if waterfalls else None,
            "server_retransmits": statistics.median(row.get("server_retransmits", 0) for row in samples.values()),
        }
        phases = [use[row["phase"]] for row in samples.values() if row["phase"] in use]
        if phases:
            entry["connections"] = statistics.median(p["count"] for p in phases)
            entry["busy"] = statistics.median(p["busy"] for p in phases)
        if variant != REFERENCE and REFERENCE in by_variant:
            pairs = [samples[s]["wall_ms"] - by_variant[REFERENCE][s]["wall_ms"] for s in samples if s in by_variant[REFERENCE]]
            entry["paired_ms"] = round(statistics.median(pairs))
            entry["faster"] = f"{sum(d < 0 for d in pairs)}/{len(pairs)}"
        result[variant] = entry
    return result


def main():
    paths = sys.argv[1:] or sorted(glob.glob(os.path.join(ROOT, "results", "diag-p2-*.json")))
    paths = [p for p in paths if not p.endswith("-status.json")]
    out = {}
    for path in paths:
        name = os.path.basename(path)[len("diag-"):-len(".json")]
        out[name] = summarize(path)
        print(f"\n{name}")
        for variant, e in out[name].items():
            paired = f" paired {e['paired_ms']:+5d} ({e['faster']})" if "paired_ms" in e else " " * 20
            print(f"  {variant:13} median {e['median_ms']:6d} p95 {e['p95_ms']:6d}{paired} resolve {e['resolve_ms']} fetch {e['fetch_ms']} retx {e['server_retransmits']} conns {e.get('connections')} busy {e.get('busy')}")
    json.dump(out, open(os.path.join(ROOT, "results", "phase2-summary.json"), "w"), indent=2)


if __name__ == "__main__":
    main()
