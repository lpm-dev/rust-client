#!/bin/bash
B=/Users/tolga/Documents/Projects/lpm-dev/performance-runs/20260925/tarball-lanes
for cell in "p5-rtt0-lowat 0" "p5-rtt20-lowat 10" "p5-rtt50-lowat 25" "p5-rtt100-lowat 50"; do
  set -- $cell
  echo "$(date '+%H:%M:%S') start $1" >> "$B/results/phase5-driver.log"
  LPM_BENCH_TIMING=1 "$B/run3.sh" "$1" "$2" 1000 4194304 lowat 16 >> "$B/results/phase5.log" 2>&1 || echo "$(date '+%H:%M:%S') FAILED $1" >> "$B/results/phase5-driver.log"
done
echo "$(date '+%H:%M:%S') phase5 done" >> "$B/results/phase5-driver.log"
