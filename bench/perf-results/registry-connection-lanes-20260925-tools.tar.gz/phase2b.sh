#!/bin/bash
B=/Users/tolga/Documents/Projects/lpm-dev/performance-runs/20260925/tarball-lanes
until grep -q "phase2 done" "$B/results/phase2-driver.log"; do sleep 10; done
echo "$(date '+%H:%M:%S') start p2-rtt50-default" >> "$B/results/phase2-driver.log"
LPM_BENCH_TIMING=1 "$B/run2b.sh" p2-rtt50-default 25 1000 4194304 default 10 shared,h1-pool,spread-4,spread-all-4,spread-all-8 >> "$B/results/phase2.log" 2>&1 || echo "$(date '+%H:%M:%S') FAILED p2-rtt50-default" >> "$B/results/phase2-driver.log"
echo "$(date '+%H:%M:%S') phase2b done" >> "$B/results/phase2-driver.log"
