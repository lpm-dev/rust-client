#!/bin/bash
U=https://registry.npmjs.org/next/-/next-16.3.6.tgz
C="curl --http2 -x http://server:8080 --cacert /bench/ca/ca.pem -s -o /dev/null"
echo "one connection, sequential x4 (bytes/s):"
$C -w '%{speed_download}\n' $U -o /dev/null $U -o /dev/null $U -o /dev/null $U
for n in 2 4; do
  start=$(date +%s.%N)
  for i in $(seq 1 $n); do $C $U & done; wait
  end=$(date +%s.%N)
  awk -v n=$n -v s=$start -v e=$end 'BEGIN{printf "%d parallel connections: %.1f MB/s aggregate\n", n, n*41747455/(e-s)/1e6}'
done
