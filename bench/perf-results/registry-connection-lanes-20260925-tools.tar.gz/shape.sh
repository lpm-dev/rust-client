#!/bin/sh
# shape.sh ONE_WAY_DELAY_MS RATE_MBIT: pace eth0 with netem and a ~2xBDP queue; offloads off.
set -eu
delay=$1; rate=$2
ethtool -K eth0 gso off tso off gro off >/dev/null 2>&1 || true
limit=$(( delay * 2 * rate * 125000 / 1000 * 2 / 1500 ))
[ "$limit" -lt 1000 ] && limit=1000
tc qdisc del dev eth0 root 2>/dev/null || true
tc qdisc add dev eth0 root netem delay ${delay}ms rate ${rate}mbit limit $limit
