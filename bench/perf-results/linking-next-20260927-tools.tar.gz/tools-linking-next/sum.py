import json,sys,statistics
H,fx,stage,base,change=sys.argv[1:6]
def p95(v): v=sorted(v); return v[max(0,-(-len(v)*95//100)-1)]
rows=json.load(open(f"{H}/{fx}/{stage}/rows.json"))
for st in ['first-install','fresh-checkout-warm-cache','ci-cold-cache']:
    by={}
    for r in rows:
        if r['scenario']==st: by.setdefault(r['variant'],{})[r['sample']]=r['wall_ms']
    if not by: continue
    b,c=by[base],by[change]; d=[c[s]-b[s] for s in b if s in c]
    u=by.get('bun',{})
    print(f"{fx:12} {st:26} {base} {statistics.median(b.values()):7.1f}/{p95(b.values()):7.1f}  {change} {statistics.median(c.values()):7.1f}/{p95(c.values()):7.1f}  paired {statistics.median(d):+6.1f} ({sum(x<0 for x in d)}/{len(d)})" + (f"  bun {statistics.median(u.values()):7.1f}" if u else ""))
