import subprocess,statistics,shutil,os,sys
B="/private/tmp/claude-501/-Users-tolga-Documents-Projects-tolgaergin-a-package-manager/dfb517ff-cb21-4ed5-8c69-7812053af855/scratchpad/clonebench"; SRC="/private/tmp/claude-501/-Users-tolga-Documents-Projects-tolgaergin-a-package-manager/dfb517ff-cb21-4ed5-8c69-7812053af855/scratchpad/locks/home/.lpm/store/v2/objects/sha512-2fea2d58cfda41b613c7df1a661804a0c6f86d9017c756155b850c03fbee0b20a8586e472726548a58bc40092aceb702fb9ffffedb33decd0cf929720796cb33"
variants=[("tree",["tree"]),("files-1",["files","1"]),("files-4",["files","4"]),("files-8",["files","8"]),("sub3-4",["subtrees","3","4"]),("sub3-8",["subtrees","3","8"]),("sub4-8",["subtrees","4","8"]),("sub5-8",["subtrees","5","8"])]
res={n:[] for n,_ in variants}; info={}
for r in range(7):
    order=variants[r%len(variants):]+variants[:r%len(variants)]
    for name,args in order:
        dst=f"{B}/out"
        if os.path.exists(dst): shutil.rmtree(dst)
        out=subprocess.run([f"{B}/clonebench",SRC,dst,*args],capture_output=True,text=True,check=True).stdout.split()
        res[name].append(float(out[0])); info[name]=out[1:]
        shutil.rmtree(dst)
for name,_ in variants:
    v=sorted(res[name]); print(f"{name:8} median {statistics.median(v):7.1f} ms  min {v[0]:7.1f}  max {v[-1]:7.1f}  walk {info[name][0]} dirs {info[name][1]} files {info[name][2]} subtrees {info[name][3]}")
