#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
static double now_ms(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec * 1e3 + t.tv_nsec / 1e6; }
int main(int argc, char **argv) {
  /* reopen <root> <parents.txt> <mode: open|fstatat> */
  int root = open(argv[1], O_RDONLY | O_DIRECTORY);
  FILE *f = fopen(argv[2], "r"); char line[4096]; char **v = NULL; int n = 0, cap = 0;
  while (fgets(line, sizeof line, f)) { line[strcspn(line, "\n")] = 0; if (n == cap) { cap = cap ? cap * 2 : 1024; v = realloc(v, cap * sizeof *v); } v[n++] = strdup(line); }
  int open_mode = !strcmp(argv[3], "open");
  double t0 = now_ms(); long sink = 0;
  for (int i = 0; i < n; i++) {
    struct stat st;
    if (open_mode) {
      int fd = openat(root, v[i], O_SEARCH | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW_ANY);
      if (fd < 0) { perror(v[i]); return 1; }
      fstat(fd, &st); sink += st.st_ino; close(fd);
    } else {
      if (fstatat(root, v[i], &st, AT_SYMLINK_NOFOLLOW_ANY) != 0) { perror(v[i]); return 1; }
      sink += st.st_ino;
    }
  }
  printf("%s %d lookups %.1f ms (%.2f us each) %ld\n", argv[3], n, now_ms() - t0, (now_ms() - t0) * 1e3 / n, sink % 7);
  return 0;
}
