import subprocess,statistics,shutil,os,time
B="/private/tmp/claude-501/-Users-tolga-Documents-Projects-tolgaergin-a-package-manager/dfb517ff-cb21-4ed5-8c69-7812053af855/scratchpad/clonebench"; SRC="/private/tmp/claude-501/-Users-tolga-Documents-Projects-tolgaergin-a-package-manager/dfb517ff-cb21-4ed5-8c69-7812053af855/scratchpad/locks/home/.lpm/store/v2/objects/sha512-2fea2d58cfda41b613c7df1a661804a0c6f86d9017c756155b850c03fbee0b20a8586e472726548a58bc40092aceb702fb9ffffedb33decd0cf929720796cb33"
fresh=f"{B}/fresh"; out=f"{B}/out"
res={"dirty":[],"flushed":[]}
for r in range(6):
    for mode in (["dirty","flushed"] if r%2==0 else ["flushed","dirty"]):
        for p in (fresh,out):
            if os.path.exists(p): shutil.rmtree(p)
        subprocess.run(["cp","-R",SRC,fresh],check=True)   # writes data: dirty pages
        if mode=="flushed":
            subprocess.run(["sync"],check=True); time.sleep(1.0)
        t=float(subprocess.run([f"{B}/clonebench",fresh,out,"tree"],capture_output=True,text=True,check=True).stdout.split()[0])
        res[mode].append(t)
for p in (fresh,out):
    if os.path.exists(p): shutil.rmtree(p)
for k,v in res.items(): print(k, "median %.1f ms" % statistics.median(v), sorted(round(x,1) for x in v))
