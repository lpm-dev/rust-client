#include <dirent.h>
#include <errno.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/clonefile.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

typedef struct { char **v; int n, cap; } list;
static void push(list *l, const char *s) { if (l->n == l->cap) { l->cap = l->cap ? l->cap * 2 : 1024; l->v = realloc(l->v, l->cap * sizeof *l->v); } l->v[l->n++] = strdup(s); }
static const char *SRC; static char DST[4096];
static list dirs, files, subtrees;
static int DEPTH;

/* Walk src: record relative dirs (pre-order) and files; entries at depth == DEPTH that are dirs become subtrees. */
static void walk(const char *rel, int depth, int split) {
  char path[4096]; snprintf(path, sizeof path, "%s/%s", SRC, rel);
  DIR *d = opendir(path); struct dirent *e;
  while ((e = readdir(d))) {
    if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
    char r[4096]; snprintf(r, sizeof r, "%s%s%s", rel, *rel ? "/" : "", e->d_name);
    if (e->d_type == DT_DIR) {
      if (split && depth + 1 >= DEPTH) push(&subtrees, r);
      else { push(&dirs, r); walk(r, depth + 1, split); }
    } else push(&files, r);
  }
  closedir(d);
}

static list *WORK; static atomic_int next_i;
static void *worker(void *arg) {
  (void)arg; int i; char s[4096], t[4096];
  while ((i = atomic_fetch_add(&next_i, 1)) < WORK->n) {
    snprintf(s, sizeof s, "%s/%s", SRC, WORK->v[i]); snprintf(t, sizeof t, "%s/%s", DST, WORK->v[i]);
    if (clonefile(s, t, CLONE_NOFOLLOW) != 0) { perror(t); exit(1); }
  }
  return NULL;
}
static void run_parallel(list *l, int threads) {
  WORK = l; atomic_store(&next_i, 0); pthread_t th[64];
  for (int k = 0; k < threads; k++) pthread_create(&th[k], NULL, worker, NULL);
  for (int k = 0; k < threads; k++) pthread_join(th[k], NULL);
}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1e3 + ts.tv_nsec / 1e6; }

int main(int argc, char **argv) {
  /* usage: clonebench <src> <dst> tree | files <threads> | subtrees <depth> <threads> */
  SRC = argv[1]; snprintf(DST, sizeof DST, "%s", argv[2]); const char *mode = argv[3];
  double t0 = now_ms(), walk_ms = 0;
  if (!strcmp(mode, "tree")) {
    if (clonefile(SRC, DST, CLONE_NOFOLLOW) != 0) { perror("clonefile"); return 1; }
  } else {
    int split = !strcmp(mode, "subtrees"); DEPTH = split ? atoi(argv[4]) : 1 << 30;
    int threads = atoi(argv[split ? 5 : 4]);
    walk("", 0, split); walk_ms = now_ms() - t0;
    mkdir(DST, 0755);
    for (int i = 0; i < dirs.n; i++) { char t[4096]; snprintf(t, sizeof t, "%s/%s", DST, dirs.v[i]); if (mkdir(t, 0755) && errno != EEXIST) { perror(t); return 1; } }
    list all = {0}; for (int i = 0; i < subtrees.n; i++) push(&all, subtrees.v[i]); for (int i = 0; i < files.n; i++) push(&all, files.v[i]);
    run_parallel(&all, threads);
  }
  printf("%.1f %.1f %d %d %d\n", now_ms() - t0, walk_ms, dirs.n, files.n, subtrees.n);
  return 0;
}
