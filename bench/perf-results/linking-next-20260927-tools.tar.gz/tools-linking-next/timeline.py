"""Per-run timeline of the largest package from LPM_FETCH_TRACE / LPM_LINK_TRACE / LPM_TAIL_MARK.

Usage: timeline.py <stderr.log> ... (times in ms from install start)
"""
import json, re, statistics, sys
rows = []
for path in sys.argv[1:]:
    fetch, links, marks = [], {}, {}
    for line in open(path, errors="replace"):
        if "LPM_FETCH_TRACE " in line:
            fetch.append(json.loads(line.split("LPM_FETCH_TRACE ", 1)[1]))
        elif "LPM_LINK_TRACE " in line:
            f = dict(kv.split("=", 1) for kv in line.split("LPM_LINK_TRACE ", 1)[1].split())
            links[f["name"]] = f
        elif "LPM_TAIL_MARK " in line:
            label, elapsed, epoch = line.split("LPM_TAIL_MARK ", 1)[1].split()
            marks[label] = (int(elapsed), int(epoch))
    if "link_end" not in marks or not fetch:
        continue
    t0 = marks["link_end"][1] - marks["link_end"][0]
    ms = lambda us: (us - t0) / 1000
    big = max(fetch, key=lambda r: r["unpacked_bytes"])
    wall = max(big["stream_body_wall_ms"], big["download_ms"] + big["extract_ms"])
    busy = big["queue_wait_ms"] + big["download_headers_ms"] + big["extract_permit_wait_ms"] + wall + big["finalize_ms"]
    end = ms(big["end_us"])
    others = [r for r in fetch if r is not big]
    overlapping = [r for r in others if ms(r["end_us"]) > end - wall]
    name = big["package"].split("@")[0] if not big["package"].startswith("@") else "@" + big["package"][1:].split("@")[0]
    link = links.get(name)
    rows.append({
        "package": big["package"], "start": end - busy, "end": end,
        "body_wall": big["stream_body_wall_ms"], "extract": big["extract_ms"], "finalize": big["finalize_ms"],
        "permit_wait": big["extract_permit_wait_ms"],
        "last_fetch_end": max(ms(r["end_us"]) for r in fetch),
        "others_ending_during_big": len(overlapping),
        "others_extract_sum_during": sum(r["extract_ms"] for r in overlapping),
        "link_start": ms(int(link["start_us"])) if link else None, "link_end_task": ms(int(link["end_us"])) if link else None,
        "link_phase_end": marks["link_end"][0] / 1000,
    })
for r in rows:
    print(" ".join(f"{k}={v:.0f}" if isinstance(v, float) else f"{k}={v}" for k, v in r.items()))
if rows:
    for k in ["start", "body_wall", "extract", "end", "last_fetch_end", "link_start", "link_end_task", "link_phase_end", "others_extract_sum_during"]:
        v = [r[k] for r in rows if r[k] is not None]
        print(f"median {k:26} {statistics.median(v):8.1f}")
