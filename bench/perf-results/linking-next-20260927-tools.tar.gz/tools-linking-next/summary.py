"""Summarize A/B runs: medians, nearest-rank p95 and paired deltas.

Usage: summary.py <research-dir> <base-id> <change-id> <fixture>:<stage>:<state,...> ...
"""

import json
import statistics
import sys


def p95(values):
    ordered = sorted(values)
    return ordered[max(0, -(-len(ordered) * 95 // 100) - 1)]


def main():
    research, base, change = sys.argv[1:4]
    result = {"base": base, "change": change, "runs": []}
    for spec in sys.argv[4:]:
        fixture, stage, states = spec.split(":")
        rows = json.load(open(f"{research}/{fixture}/{stage}/rows.json"))
        run = {"fixture": fixture, "stage": stage, "states": {}}
        for state in states.split(","):
            grouped = {}
            for row in rows:
                if row["scenario"] == state:
                    grouped.setdefault(row["variant"], {})[row["sample"]] = row["wall_ms"]
            entry = {
                variant: {
                    "median_ms": statistics.median(samples.values()),
                    "p95_ms": p95(samples.values()),
                    "wall_ms": [samples[sample] for sample in sorted(samples)],
                }
                for variant, samples in grouped.items()
            }
            deltas = [grouped[change][s] - grouped[base][s] for s in grouped[base] if s in grouped[change]]
            entry["paired_change_minus_base"] = {
                "median_ms": statistics.median(deltas),
                "faster_pairs": sum(delta < 0 for delta in deltas),
                "pairs": len(deltas),
            }
            run["states"][state] = entry
        result["runs"].append(run)
    json.dump(result, sys.stdout, indent=1)
    print()


if __name__ == "__main__":
    main()
