"""Summarize the cold fetch A/B runs: medians, nearest-rank p95 and paired deltas."""

import json
import statistics
import sys

STATES = [
    "first-install",
    "fresh-checkout-warm-cache",
    "ci-cold-cache",
    "ci-warm-cache",
    "installed-cache-gone",
    "up-to-date",
]


def p95(values):
    ordered = sorted(values)
    return ordered[max(0, -(-len(ordered) * 95 // 100) - 1)]


def by_variant(rows, state):
    grouped = {}
    for row in rows:
        if row["scenario"] == state:
            grouped.setdefault(row["variant"], {})[row["sample"]] = row["wall_ms"]
    return grouped


def paired(change, base):
    deltas = [change[sample] - base[sample] for sample in base if sample in change]
    return {
        "median_ms": statistics.median(deltas),
        "faster_pairs": sum(delta < 0 for delta in deltas),
        "pairs": len(deltas),
    }


def summarize(rows, states, base, change, reference):
    summary = {}
    for state in states:
        grouped = by_variant(rows, state)
        if not grouped:
            continue
        entry = {
            variant: {
                "median_ms": statistics.median(samples.values()),
                "p95_ms": p95(samples.values()),
                "samples": len(samples),
                "wall_ms": [samples[sample] for sample in sorted(samples)],
            }
            for variant, samples in grouped.items()
        }
        entry["paired_change_minus_base"] = paired(grouped[change], grouped[base])
        if reference in grouped:
            entry["paired_change_minus_reference"] = paired(grouped[change], grouped[reference])
        summary[state] = entry
    return summary


def main():
    research, stage, focused_fixture, focused_stage = sys.argv[1:5]
    result = {"base": "lpm-895", "change": "lpm-final", "reference": "bun", "fixtures": {}}
    for fixture in ("nest", "vite-react", "native-sharp"):
        rows = json.load(open(f"{research}/{fixture}/{stage}/rows.json"))
        result["fixtures"][fixture] = summarize(rows, STATES, "lpm-895", "lpm-final", "bun")
    rows = json.load(open(f"{research}/{focused_fixture}/{focused_stage}/rows.json"))
    result["focused"] = {
        "fixture": focused_fixture,
        "states": summarize(
            rows,
            ["fresh-checkout-warm-cache", "ci-cold-cache", "ci-warm-cache"],
            "lpm-895",
            "lpm-final",
            "bun",
        ),
    }
    json.dump(result, sys.stdout, indent=1)
    print()


if __name__ == "__main__":
    main()
