use std::collections::VecDeque;
use std::ffi::CString;
use std::os::unix::ffi::OsStrExt;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Condvar, Mutex};
use std::time::Instant;

fn clonefile(src: &Path, dst: &Path) {
    let s = CString::new(src.as_os_str().as_bytes()).unwrap();
    let d = CString::new(dst.as_os_str().as_bytes()).unwrap();
    let rc = unsafe { libc::clonefile(s.as_ptr(), d.as_ptr(), 0) };
    assert_eq!(rc, 0, "clonefile {} -> {}: {}", src.display(), dst.display(), std::io::Error::last_os_error());
}

fn count(dir: &Path) -> usize {
    let mut n = 0;
    for e in std::fs::read_dir(dir).unwrap() {
        let e = e.unwrap();
        n += 1;
        if e.file_type().unwrap().is_dir() { n += count(&e.path()); }
    }
    n
}

/// Split the tree into clone units: directories whose subtree is at most `unit`
/// entries are cloned whole; larger directories are created and descended.
fn plan(src: &Path, rel: &Path, unit: usize, dirs: &mut Vec<PathBuf>, jobs: &mut Vec<(usize, PathBuf)>) {
    for e in std::fs::read_dir(src.join(rel)).unwrap() {
        let e = e.unwrap();
        let r = rel.join(e.file_name());
        if e.file_type().unwrap().is_dir() {
            let size = count(&e.path()) + 1;
            if size > unit { dirs.push(r.clone()); plan(src, &r, unit, dirs, jobs); } else { jobs.push((size, r)); }
        } else {
            jobs.push((1, r));
        }
    }
}

fn run_pool(threads: usize, jobs: Vec<(usize, PathBuf)>, work: impl Fn(&Path) + Sync) {
    let queue = Mutex::new(VecDeque::from(jobs));
    std::thread::scope(|scope| {
        for _ in 0..threads {
            scope.spawn(|| loop {
                let job = queue.lock().unwrap().pop_front();
                match job { Some((_, rel)) => work(&rel), None => break }
            });
        }
    });
}

fn walk_seq(dir: &Path) -> usize {
    let mut n = 0;
    for e in std::fs::read_dir(dir).unwrap() {
        let e = e.unwrap();
        let m = std::fs::symlink_metadata(e.path()).unwrap();
        n += 1;
        if m.is_dir() { n += walk_seq(&e.path()); }
    }
    n
}

fn walk_par(root: &Path, threads: usize) -> usize {
    let state = Arc::new((Mutex::new((vec![root.to_path_buf()], 0usize, 0usize)), Condvar::new()));
    std::thread::scope(|scope| {
        for _ in 0..threads {
            let state = Arc::clone(&state);
            scope.spawn(move || loop {
                let (lock, cv) = &*state;
                let dir = {
                    let mut g = lock.lock().unwrap();
                    loop {
                        if let Some(d) = g.0.pop() { g.1 += 1; break Some(d); }
                        if g.1 == 0 { cv.notify_all(); break None; }
                        g = cv.wait(g).unwrap();
                    }
                };
                let Some(dir) = dir else { break };
                let mut subdirs = Vec::new(); let mut n = 0;
                for e in std::fs::read_dir(&dir).unwrap() {
                    let e = e.unwrap();
                    let m = std::fs::symlink_metadata(e.path()).unwrap();
                    n += 1;
                    if m.is_dir() { subdirs.push(e.path()); }
                }
                let mut g = lock.lock().unwrap();
                g.0.extend(subdirs); g.1 -= 1; g.2 += n; cv.notify_all();
            });
        }
    });
    let g = state.0.lock().unwrap(); g.2
}

fn main() {
    let src = PathBuf::from(std::env::args().nth(1).unwrap());
    let scratch = PathBuf::from(std::env::args().nth(2).unwrap());
    let rounds = 7;
    let median = |mut v: Vec<f64>| { v.sort_by(|a, b| a.partial_cmp(b).unwrap()); v[v.len() / 2] };
    let fresh = |tag: &str, i: usize| { let p = scratch.join(format!("{tag}-{i}")); let _ = std::fs::remove_dir_all(&p); p };

    let mut whole = Vec::new();
    for i in 0..rounds { let d = fresh("whole", i); let t = Instant::now(); clonefile(&src, &d); whole.push(t.elapsed().as_secs_f64() * 1e3); }
    println!("clone whole dir: median {:.1} ms", median(whole));

    for unit in [1usize, 64, 512] {
        let (mut dirs, mut jobs) = (Vec::new(), Vec::new());
        let t = Instant::now(); plan(&src, Path::new(""), unit, &mut dirs, &mut jobs); let plan_ms = t.elapsed().as_secs_f64() * 1e3;
        jobs.sort_by(|a, b| b.0.cmp(&a.0));
        for threads in [1usize, 2, 4, 8] {
            let mut times = Vec::new();
            for i in 0..rounds {
                let d = fresh(&format!("split{unit}-{threads}"), i);
                let t = Instant::now();
                std::fs::create_dir(&d).unwrap();
                for dir in &dirs { std::fs::create_dir(d.join(dir)).unwrap(); }
                run_pool(threads, jobs.clone(), |rel| clonefile(&src.join(rel), &d.join(rel)));
                times.push(t.elapsed().as_secs_f64() * 1e3);
            }
            println!("clone split unit={unit:>3} (dirs={}, jobs={}) threads={threads}: median {:.1} ms (+plan {:.1} ms)", dirs.len(), jobs.len(), median(times), plan_ms);
        }
    }
    let target = scratch.join("whole-0");
    let mut seq = Vec::new(); for _ in 0..rounds { let t = Instant::now(); walk_seq(&target); seq.push(t.elapsed().as_secs_f64() * 1e3); }
    println!("walk sequential lstat: median {:.1} ms ({} entries)", median(seq), walk_seq(&target));
    for threads in [2usize, 4, 8] {
        let mut par = Vec::new(); for _ in 0..rounds { let t = Instant::now(); walk_par(&target, threads); par.push(t.elapsed().as_secs_f64() * 1e3); }
        println!("walk parallel threads={threads}: median {:.1} ms ({} entries)", median(par), walk_par(&target, threads));
    }
}
