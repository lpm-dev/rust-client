"""Balanced A/B of warm T3 installs: #887 binary vs parallel metadata walk."""
import json, os, shutil, statistics, subprocess, sys, time

SP = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.join(SP, "project")
HOME = os.path.join(SP, "home")
BINARIES = {
    "baseline": "/Users/tolga/Documents/Projects/lpm-dev/performance-runs/20260924/race/binaries/lpm-race",
    "parallel": "/tmp/lpm-link-release/release/lpm-rs",
}
ROUNDS = int(sys.argv[1]) if len(sys.argv) > 1 else 24
ENV = {"PATH": os.environ["PATH"], "HOME": os.path.join(SP, "isolated-home"), "TMPDIR": os.environ["TMPDIR"], "LPM_HOME": HOME}
LOCK = os.path.join(PROJECT, "lpm.lock")
with open(LOCK) as handle:
    lock_bytes = handle.read()

def reset(state):
    for name in ("node_modules", ".lpm"):
        shutil.rmtree(os.path.join(PROJECT, name), ignore_errors=True)
    if state == "fresh-checkout":
        os.remove(LOCK)
    else:
        with open(LOCK, "w") as handle:
            handle.write(lock_bytes)

def install(binary, timing=False):
    command = [binary, "--json", "install", "--no-security-summary", "--no-skills", "--no-editor-setup"]
    env = dict(ENV)
    if timing:
        command.append("--timing"); env["LPM_TIMING_DETAIL"] = "trace"
    started = time.perf_counter()
    result = subprocess.run(command, cwd=PROJECT, env=env, capture_output=True, text=True)
    wall = (time.perf_counter() - started) * 1e3
    assert result.returncode == 0, result.stderr[-2000:]
    return wall, json.loads(result.stdout)

def nearest_rank(values, percentile):
    ordered = sorted(values); return ordered[max(1, -(-len(ordered) * percentile // 100)) - 1]

rows = []
for state in ("ci-warm", "fresh-checkout"):
    for variant in BINARIES:  # two unscored warm gates per variant
        for _ in range(2):
            reset(state); install(BINARIES[variant])
    for sample in range(ROUNDS):
        order = list(BINARIES) if sample % 2 == 0 else list(reversed(BINARIES))
        for variant in order:
            reset(state)
            wall, _ = install(BINARIES[variant])
            rows.append({"state": state, "variant": variant, "sample": sample, "wall_ms": wall})
    diag = {}
    for variant in BINARIES:
        links = []
        for _ in range(4):
            reset(state)
            _, parsed = install(BINARIES[variant], timing=True)
            slow = parsed["timing"]["detail"]["trace"]["slow_packages"]["link_v2_one"]
            next_row = next(row for row in slow if row["package"].startswith("next@"))
            links.append((parsed["timing"]["waterfall"]["link_ms"], next_row["reuse_check_ms"]))
        diag[variant] = links
    for variant in BINARIES:
        walls = [row["wall_ms"] for row in rows if row["state"] == state and row["variant"] == variant]
        print(f"{state:15} {variant:9} n={len(walls)} median={statistics.median(walls):6.1f} p95={nearest_rank(walls, 95):6.1f}  diag (link_ms, next reuse_check_ms)={diag[variant]}")
    paired = [
        next(r["wall_ms"] for r in rows if r["state"] == state and r["variant"] == "parallel" and r["sample"] == s)
        - next(r["wall_ms"] for r in rows if r["state"] == state and r["variant"] == "baseline" and r["sample"] == s)
        for s in range(ROUNDS)
    ]
    print(f"{state:15} paired parallel-baseline median={statistics.median(paired):+.1f} ms, faster {sum(d < 0 for d in paired)}/{ROUNDS}")
reset("ci-warm")
json.dump(rows, open(os.path.join(SP, "warm_ab_rows.json"), "w"), indent=1)
