//! HTTP/2 flow-control windows under real TCP latency (tc netem on lo).
use bytes::Bytes;
use futures_util::StreamExt as _;
use http_body_util::StreamBody;
use hyper::body::Frame;
use std::time::Instant;

const CHUNK: usize = 64 * 1024;

async fn serve(port: u16) {
    let listener = tokio::net::TcpListener::bind(("0.0.0.0", port)).await.unwrap();
    loop {
        let (stream, _) = listener.accept().await.unwrap();
        stream.set_nodelay(true).unwrap();
        tokio::spawn(async move {
            let service = hyper::service::service_fn(|request: hyper::Request<hyper::body::Incoming>| async move {
                let size: usize = request.uri().path().trim_start_matches('/').parse().unwrap_or(0);
                let chunks = futures_util::stream::iter((0..size.div_ceil(CHUNK)).map(move |index| {
                    let len = CHUNK.min(size - index * CHUNK);
                    Ok::<_, std::convert::Infallible>(Frame::data(Bytes::from(vec![7u8; len])))
                }));
                Ok::<_, std::convert::Infallible>(hyper::Response::new(StreamBody::new(chunks)))
            });
            let _ = hyper::server::conn::http2::Builder::new(hyper_util::rt::TokioExecutor::new())
                .max_concurrent_streams(256)
                .serve_connection(hyper_util::rt::TokioIo::new(stream), service)
                .await;
        });
    }
}

fn client(variant: &str) -> reqwest::Client {
    let builder = reqwest::Client::builder().http2_prior_knowledge();
    match variant {
        "default" | "split" => builder,
        "adaptive" => builder.http2_adaptive_window(true),
        "s8c16" => builder
            .http2_initial_stream_window_size(8 * 1024 * 1024)
            .http2_initial_connection_window_size(16 * 1024 * 1024),
        "s16c32" => builder
            .http2_initial_stream_window_size(16 * 1024 * 1024)
            .http2_initial_connection_window_size(32 * 1024 * 1024),
        other => panic!("unknown variant {other}"),
    }
    .build()
    .unwrap()
}

async fn fetch(client: &reqwest::Client, base: &str, size: usize) -> Instant {
    let response = client.get(format!("{base}/{size}")).send().await.unwrap();
    let mut body = response.bytes_stream();
    let mut received = 0;
    while let Some(chunk) = body.next().await {
        received += chunk.unwrap().len();
    }
    assert_eq!(received, size);
    Instant::now()
}

fn retransmitted_segments() -> u64 {
    let snmp = std::fs::read_to_string("/proc/net/snmp").unwrap_or_default();
    let mut lines = snmp.lines().filter(|line| line.starts_with("Tcp:"));
    let (Some(header), Some(values)) = (lines.next(), lines.next()) else { return 0 };
    header.split_whitespace().zip(values.split_whitespace())
        .find(|(name, _)| *name == "RetransSegs")
        .and_then(|(_, value)| value.parse().ok())
        .unwrap_or(0)
}

async fn bench(base: String, label: String, reps: usize) {
    let variants: Vec<String> = std::env::var("VARIANTS").map(|v| v.split(',').map(str::to_owned).collect()).unwrap_or_else(|_| ["default", "adaptive", "s8c16", "s16c32"].map(str::to_owned).to_vec());
    for variant in variants.iter().map(String::as_str) {
        for rep in 0..reps {
            let client = client(variant);
            fetch(&client, &base, 1).await; // establish the connection outside the timing
            let retrans_before = retransmitted_segments();
            let started = Instant::now();
            fetch(&client, &base, 42_000_000).await;
            let single = started.elapsed().as_secs_f64() * 1e3;

            let client = self::client(if variant == "split" { "default" } else { variant });
            fetch(&client, &base, 1).await;
            // "split" carries large bodies on a second connection.
            let large_client = if variant == "split" { self::client("default") } else { client.clone() };
            fetch(&large_client, &base, 1).await;
            let started = Instant::now();
            let mut sizes = vec![50_000; 40];
            sizes.extend([1_000_000; 10]);
            sizes.extend([35_000_000; 2]);
            let finished = futures_util::future::join_all(sizes.iter().map(|size| {
                let owner = if *size >= 35_000_000 { &large_client } else { &client };
                fetch(owner, &base, *size)
            })).await;
            let small_done = finished[..40].iter().max().unwrap().duration_since(started).as_secs_f64() * 1e3;
            let all_done = finished.iter().max().unwrap().duration_since(started).as_secs_f64() * 1e3;
            let retransmits = retransmitted_segments() - retrans_before;
            println!("{{\"label\":\"{label}\",\"variant\":\"{variant}\",\"rep\":{rep},\"single_42mb_ms\":{single:.1},\"mix_small_done_ms\":{small_done:.1},\"mix_all_done_ms\":{all_done:.1},\"retransmits\":{retransmits}}}");
        }
    }
}

#[tokio::main]
async fn main() {
    let args: Vec<String> = std::env::args().collect();
    match args[1].as_str() {
        "serve" => serve(args[2].parse().unwrap()).await,
        "bench" => bench(args[2].clone(), args[3].clone(), args[4].parse().unwrap()).await,
        _ => panic!("usage: serve PORT | bench BASE LABEL REPS"),
    }
}
