#!/bin/bash
# Host driver: separate client/server containers, netem on each eth0.
set -euo pipefail
N="$1"; REPS="${2:-5}"
docker network create h2net >/dev/null 2>&1 || true
docker run --rm -v "$N":/bench -v lpm-netem-cargo:/usr/local/cargo/registry -v lpm-netem-target:/target rust:1.94-slim sh -c 'cd /bench && CARGO_TARGET_DIR=/target cargo build --release -q' 1>&2
for rmem in 4194304 6291456; do
  for delay in 0 10 25 50; do
    docker rm -f h2server h2client >/dev/null 2>&1 || true
    docker run -d --name h2server --network h2net --cap-add NET_ADMIN -v "$N":/bench -v lpm-netem-cargo:/usr/local/cargo/registry -v lpm-netem-target:/target rust:1.94-slim sh -c "/bench/shape.sh $delay && /target/release/h2netem serve 8080" >/dev/null
    docker run --rm --name h2client --network h2net --cap-add NET_ADMIN --sysctl net.ipv4.tcp_rmem="4096 131072 $rmem" --sysctl net.ipv4.tcp_wmem="4096 16384 16777216" -v "$N":/bench -v lpm-netem-cargo:/usr/local/cargo/registry -v lpm-netem-target:/target rust:1.94-slim sh -c "/bench/shape.sh $delay && sleep 2 && /target/release/h2netem bench http://h2server:8080 rtt=$((delay*2))ms,rmem=$rmem $REPS"
  done
done
docker rm -f h2server >/dev/null 2>&1 || true
docker network rm h2net >/dev/null 2>&1 || true
