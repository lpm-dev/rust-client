#!/bin/sh
# shape.sh DELAY_MS: pace eth0 at 1 Gbit/s with DELAY_MS one-way delay and a ~2xBDP queue.
set -eu
command -v tc >/dev/null && command -v ethtool >/dev/null || (apt-get update -qq && apt-get install -y -qq iproute2 ethtool >/dev/null 2>&1)
ethtool -K eth0 gso off tso off gro off >/dev/null 2>&1 || true
limit=$(( $1 * 2 * 125000000 / 1000 * 2 / 1500 ))
[ "$limit" -lt 1000 ] && limit=1000
tc qdisc del dev eth0 root 2>/dev/null || true
tc qdisc add dev eth0 root netem delay ${1}ms rate 1gbit limit $limit
