#!/bin/bash
set -euo pipefail
N="$1"
docker network create h2net >/dev/null 2>&1 || true
docker run --rm -v "$N":/bench -v lpm-netem-cargo:/usr/local/cargo/registry -v lpm-netem-target:/target rust:1.94-slim sh -c 'cd /bench && CARGO_TARGET_DIR=/target cargo build --release -q' 1>&2
for cell in "4194304 25" "4194304 50" "6291456 50"; do
  set -- $cell; rmem=$1; delay=$2
  docker rm -f h2server h2client >/dev/null 2>&1 || true
  docker run -d --name h2server --network h2net --cap-add NET_ADMIN -v "$N":/bench -v lpm-netem-cargo:/usr/local/cargo/registry -v lpm-netem-target:/target rust:1.94-slim sh -c "/bench/shape.sh $delay && /target/release/h2netem serve 8080" >/dev/null
  docker run --rm --name h2client --network h2net --cap-add NET_ADMIN -e VARIANTS=default,split --sysctl net.ipv4.tcp_rmem="4096 131072 $rmem" --sysctl net.ipv4.tcp_wmem="4096 16384 16777216" -v "$N":/bench -v lpm-netem-cargo:/usr/local/cargo/registry -v lpm-netem-target:/target rust:1.94-slim sh -c "/bench/shape.sh $delay && sleep 2 && /target/release/h2netem bench http://h2server:8080 rtt=$((delay*2))ms,rmem=$rmem 5"
done
docker rm -f h2server >/dev/null 2>&1 || true
docker network rm h2net >/dev/null 2>&1 || true
